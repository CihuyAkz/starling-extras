# Modpacks: porting any pack to Horizon

Goal (Ludovic, 2026-10-16): **support modpacks like All the Mods 10 far better than Minecraft
does, and be able to port any of them.** "Better" is measured: pack load time, RAM, FPS, TPS
and world-generation speed against the same pack on NeoForge or Fabric. "Any of them" means a
pipeline, not a list of hand ports. It takes a pack as players download it and produces native
Horizon mods. The pipeline is AI agents in dependency order, each port checked against the
original mod running in a dev-only Java instance.

This page is the design. It builds on [mods.md](modding/src/how-to/content-mods.md) (content mods, native mods, and
why Java jars cannot run in Horizon, so we port instead). The ATM10 inventory behind the numbers below is
[modpacks/atm10-mods.csv](modpacks/atm10-mods.csv).

## In one picture

```
 pack (.mrpack / CurseForge zip or instance / Prism zip or instance)
   │  import: normalise to pack.json (MC version, loader, files, hashes, overrides)
   ▼
 inventory: every jar's metadata (mods.toml / fabric.mod.json, licence, deps, file census)
   │  classify: content · client-ui · library · performance · server-only · integration · other
   │  tier:     data · logic · machines · deep · client · none
   ▼
 dependency order (libraries first, then the mods that need them)
   │
   ├─ carry-over (mechanical, no agent): assets/ + data/ upgraded to 26.3 formats,
   │    block and item registrations from the oracle's facts export  →  <mod>.hmod
   ├─ port (one agent per mod, tiers logic and up): a Rust native mod (a horizon-mixins
   │    bundle), iterating until its harness passes                  →  <mod>.hmod
   ├─ harness per mod: the Java mod in a dev-only NeoForge/Fabric oracle vs the port
   ▼
 coverage report: ported · partial · not yet · not needed, per mod and per class
```

Everything runs on the player's (or server owner's) machine, on jars they downloaded. The
results stay there. See [Licences](#licences).

## All the Mods 10, measured

**Source.** ATM10 is on CurseForge. Its GitHub repository (AllTheMods/ATM-10) carries the pack's
own mod list, `config/crash_assistant/modlist.json`, written by the Crash Assistant mod in the
pack. We used the version committed on 2026-10-15. It lists jar names, mod ids, versions,
CurseForge fingerprints and Modrinth SHA-1s. ATM10 8.x runs **Minecraft 1.21.1 on NeoForge
21.1.259**. The list has **495 jars** (494 mod ids: CC: Tweaked ships two jars) plus one
datapack (Universal Sawmill's).

**Metadata only.** Modrinth's `version_files` endpoint resolved 321 mods by hash, with their
categories, client/server sides, licence and required dependencies. A Modrinth name search
found 70 more CurseForge-only mods with a listing. The remaining 104 are CurseForge-only, so
CurseForge's API (which needs a key) would be the only source. They were classified from their
names and what they are known to do. 20 of those calls are marked `guess` in the CSV. No jar
was downloaded.

### Classes

| Class | What it is | Port? | ATM10 |
|---|---|---|---:|
| **content** | adds or changes gameplay: blocks, items, machines, mobs, worldgen, magic | yes: carry-over or agent | **287** |
| **library** | APIs and code shared by other mods (Architectury, Curios, GeckoLib, Kotlin for Forge, Balm...) | no: maps to Horizon's own code or a native mod | **80** |
| **integration** | glue between two other mods (JEI plugins, AE2 ↔ Mekanism, Create add-on wiring) | after both sides are ported | **44** |
| **client-ui** | client-only screens, HUDs, tooltips, maps, recipe viewers | yes: client API, or built in | **32** |
| **other** | pack tooling and engine features: KubeJS, Almost Unified, shader mods, CTM, crash/version tools | no: folded into the pipeline or the engine | **25** |
| **performance** | Sodium, FerriteCore, ModernFix, ImmediatelyFast, spark, AI and recipe speed-ups | no: Horizon is the replacement | **16** |
| **server-only** | admin and server features: ranks, essentials, backups, claims, spawn control | yes: server API | **11** |
| | | | **495** |

### Tiers (the API a port needs)

| Tier | Needs | ATM10 | of which content |
|---|---|---:|---:|
| **data** | registries (blocks, items) + carried-over data and assets; no code | 68 | 56 |
| **logic** | + behaviour callbacks (use, place, break, ticks), server events, config | 72 | 55 |
| **machines** | + block entities, menus and screens, capabilities (energy, items, fluids), mod networking | 101 | 89 |
| **deep** | + entities and AI, custom renderers and animated models, dimensions, new vanilla hooks (what Mixins do) | 91 | 87 |
| **client** | the client interfaces (`keys`, `target`, `inventory-read`, `ui`, `render`) | 38 | 0 |
| **none** | nothing to port | 125 | 0 |

Class by tier:

| | data | logic | machines | deep | client | none |
|---|---:|---:|---:|---:|---:|---:|
| content | 56 | 55 | 89 | 87 | | |
| library | | | | | | 80 |
| integration | 11 | 7 | 12 | 3 | 8 | 3 |
| client-ui | | | | | 30 | 2 |
| other | 1 | | | | | 24 |
| performance | | | | | | 16 |
| server-only | | 10 | | 1 | | |

What this says:

- **A quarter of ATM10 needs no port at all** (125: libraries, performance mods, pack tooling).
  Horizon's renderer and simulation replace the performance mods. Libraries become API
  features: Curios becomes accessory slots, GeckoLib an animated-model format, Patchouli,
  Modonomicon and GuideME a guide-book reader, the config libraries a config schema.
- **68 mods are data tier.** They are the structure packs (YUNG's, Moog's, Formations, CTOV,
  Towns and Towers, When Dungeons Arise), the decoration blocks (Macaw's doors, fences, paths,
  roofs, stairs; Chipped; XTones; Factory Blocks) and the ore and compression sets
  (AllTheOres, AllTheCompressed). They come over **without an agent** once registries and
  worldgen carry-over exist.
- **The big systems are deep tier.** Create, AE2, Mekanism, Ars Nouveau, Twilight Forest,
  MineColonies and Applied/Refined Storage are a long campaign of agent ports. They reach the
  most dependents: AE2 has 9 required dependents in the pack, Create 7, Ars Nouveau 6 and
  Mekanism 5.
- **Dependency depth is shallow.** Of the 321 mods with Modrinth data, 188 need nothing else
  in the pack, 103 sit one layer up, 29 two layers up and one (Apotheosis) three. The most
  required libraries are YUNG's API (10 dependents), GeckoLib, Resourceful Lib, SuperMartijn's
  core (8, 8, 7), then Curios, Bookshelf, Prickle and McJtyLib (6 each).

### Licences in ATM10

| Class | permissive (MIT, Apache, BSD, CC0, CC-BY) | copyleft (GPL, LGPL, MPL, AGPL) | All Rights Reserved | custom | non-commercial / no-derivatives | unknown (CurseForge only) |
|---|---:|---:|---:|---:|---:|---:|
| content | 93 | 46 | 62 | 16 | 9 | 61 |
| library | 27 | 20 | 9 | 6 | 4 | 14 |
| integration | 16 | 8 | 9 | 0 | 0 | 11 |
| client-ui | 13 | 5 | 3 | 5 | 1 | 5 |
| other | 6 | 8 | 4 | 1 | 0 | 6 |
| performance | 6 | 5 | 1 | 1 | 0 | 3 |
| server-only | 6 | 0 | 1 | 0 | 0 | 4 |
| **all** | **167** | **92** | **89** | **29** | **14** | **104** |

The "unknown" column is a gap in our metadata, not in the mods: NeoForge's `mods.toml` has a
mandatory `license` field, and the inventory reads it from each jar at import.

## Licences

Mods have their own licences: many are All Rights Reserved, others MIT, LGPL or MPL. A port is a
derivative work. These rules are part of the pipeline, not advice to users:

1. **Local by default.** The pipeline runs on the player's or server owner's machine, on jars
   they downloaded themselves. The ports it makes stay there. This works like `prepare` with
   Minecraft's own files: nothing is redistributed.
2. **The licence is recorded per mod** in the inventory (`license` from `mods.toml` or
   `fabric.mod.json`, plus Modrinth's SPDX id where one exists) and travels with the port into
   its `horizon-mod.toml` (`ported-from = { id, version, license, url }`).
3. **Publishing needs permission.** A port can go into a mod index, the launcher browser or a
   server's download list only if its licence allows redistributing derivatives (permissive,
   or copyleft with the port under the same licence and its source published) or the author
   has given written permission, recorded in the index entry. The tooling refuses to package
   anything else. No-derivatives and non-commercial licences (14 in ATM10) are never published.
   For them, even a local port gets a warning that the licence may not allow it.
4. **Mod code never enters this repository, and nobody reads it.** Mod jars, Java oracle builds
   with mod code, and ports of mods we have no permission to publish all live outside the
   repo: in the user's pipeline work directory, or for our own development in
   `~/code/horizon-parity/modports/` (dev-only, never pushed). A mod's code is never
   decompiled, read, quoted or paraphrased, by people or agents. Ports are written only from
   the mod's observed behaviour (the oracle and the harness), its own data files and its
   public documentation. The repository holds the pipeline, the API, metadata (ids, names, versions, licences, counts)
   and test fixtures we write ourselves.

   **Starling** (this fork) narrows the rule by licence: a mod whose code is MIT, or under another
   licence that allows copying and modifying it, may be read and its code ported, with its
   copyright and licence notice kept beside what came from it (`licenses/`). Create's code is
   MIT (its assets are All Rights Reserved and stay out). Mods under any other licence keep
   rule 4 as written.

   A port whose code may be shared but whose assets may not ships without them, and the game
   fetches them on the player's device from the mod's own file on Modrinth (Starling,
   `horizon_mods::fetch`), as `prepare` gets Minecraft's from Mojang. The manifest names the
   file by its SHA-512 and the folders the game takes from it:

   ```toml
   [assets.fetch]
   modrinth = "create"
   version = "6.0.10+mc1.21.1"
   file = "create-1.21.1-6.0.10.jar"
   size = 19123767
   sha512 = "11cc8fc0…"
   take = ["assets/create/"]
   ```

   The first start with the mod on asks Modrinth for the file with that hash, downloads it from
   Modrinth's CDN, checks it and unpacks the folders as `carry` does (the same skipped paths, the
   `items/` definitions) into `cache/mod-assets/`; the mod's content reads them as its own, its
   own files winning. The jar's code never runs and the jar is deleted. Without them (no network)
   the mod loads untextured and its row on the Mods page says why.
5. **Contacting authors or publishing any port is Ludovic's call.** Agents ask first.

This is engineering policy, not legal advice. Before anything is published, Ludovic decides,
with advice if needed.

## What packs need, and what runs today

Content mods (`.hmod`, API 0.2) carry data: blocks, items, and everything in the 26.3 data-pack and resource-pack
formats ([mods.md](modding/src/how-to/content-mods.md#content-mods-api-02)). Behaviour that needs code is not a content-mod feature: it is
written as a native mod ([modding/src/how-to/native-mods.md](modding/src/how-to/native-mods.md)), one per ported mod. What a content pack needs:

| Feature | Content mod today | Needed by (ATM10 content+integration, by tier) |
|---|---|---|
| Block registry: ids, states, properties, shapes, sounds, light | — | data and up (all 331) |
| Item registry, block items | — | data and up |
| Mob effect registry: category, colour, icon, name | — | data and up |
| Recipes, loot tables, tags, advancements, lang, blockstates, models, textures, sounds in the mod's namespace | vanilla namespace only | data and up |
| Worldgen JSON: features, structures, template pools, processors, structure NBT, biome additions | vanilla bundle only | about 30 data-tier structure and biome mods |
| Block and item behaviour callbacks: use, place, break, attack, random tick, scheduled tick, neighbour change, entity inside | — | logic and up (253) |
| Server events, typed commands, game rules | — | logic and up, server-only (11) |
| Config: typed schema in the manifest, per world and per server, a settings page | — | most mods with code |
| Block entities: per-block NBT state, ticking, client sync | — | machines and up (191) |
| Menus and screens: slots, progress bars, buttons, fluid and energy gauges | — | machines and up |
| Capabilities: energy (FE), item, fluid handlers on blocks and items | — | machines and up |
| Data attachments on entities, chunks, levels | — | machines and up |
| Accessory slots (what Curios does) | — | Curios users (6 require it, more use it optionally) |
| Mod networking between its client and server halves | — | machines and up |
| Custom recipe types: machine recipes with their own JSON | — | machines and up |
| Entities: types, attributes, AI goals and brains, spawning | — | deep (87) |
| Custom renderers and animated models (block-entity, entity, item; GeckoLib's format) | — | deep |
| Dimensions: dimension types, levels, chunk generators | — | about 10 (Twilight Forest, Aether, Ad Astra, Undergarden, ...) |
| New hooks into vanilla behaviour (what Mixins do) | — | deep |
| Client interfaces: `keys`, `target`, `inventory-read`, `ui`, `render`, `world-read` | — | client tier (38) |

One rule stays: **free when unused** (no mods means vanilla code paths and the vanilla resource root, so the parity
harnesses test the same game).

### Registries 0.2: data-driven blocks, items and mob effects

A content mod (`.hmod`) carries `assets/` and `data/` and no code:

```
ruby.hmod
├── horizon-mod.toml          id = "ruby", api = "0.2", side = "both", capabilities = ["registries"]
├── data/ruby/horizon/block/ruby_block.json
├── data/ruby/horizon/item/ruby.json
├── data/ruby/recipe/ruby_block.json            (26.3 data-pack formats)
├── data/ruby/loot_table/blocks/ruby_block.json
├── data/minecraft/tags/block/mineable/pickaxe.json   (adds to a vanilla tag)
├── assets/ruby/blockstates/ruby_block.json     (26.3 resource-pack formats)
├── assets/ruby/models/block/ruby_block.json
├── assets/ruby/items/ruby.json
├── assets/ruby/textures/block/ruby_block.png
└── assets/ruby/lang/en_us.json
```

A block declaration names a **template**, a vanilla block whose behaviour class, state
properties and shapes the new block takes, and overrides what differs:

```json
{
  "template": "minecraft:iron_block",
  "properties": { "hardness": 5.0, "explosion_resistance": 6.0, "sounds": "minecraft:iron_block",
                  "map_color": 33, "light": 0, "requires_tool": true },
  "item": true
}
```

A block may define `shapes` to replace both its selection outline and collision
shape. It selects a list of boxes by one template state property:

```json
"shapes": { "properties": ["axis"], "values": {
  "x": [[0, 0.25, 0.25, 1, 0.75, 0.75]],
  "y": [[0.25, 0, 0.25, 0.75, 1, 0.75]],
  "z": [[0.25, 0.25, 0, 0.75, 0.75, 1]]
} }
```

Each box is `[min_x, min_y, min_z, max_x, max_y, max_z]` in block units.
Each value of the template property needs an entry. Up to 16 boxes form a union;
an empty list is an empty shape. Invalid bounds or values reject the content root.
Without `shapes`, both shapes remain the template's. Other properties such as
occlusion, light, and support still come from the template.

A declaration may also set `"default_state": {"facing": "north"}`. The map
changes only those state properties on the template's default; omitted properties keep
their template values. Names and values must identify exactly one template state, or
the content root is rejected. Leave the map out to keep the template default.

Most decoration and resource blocks are vanilla classes with other numbers: Macaw's doors are
`DoorBlock`s, XTones are full cubes, ore sets are `DropExperienceBlock`s. So templates cover the
data tier without code. Templates also give mod blocks every behaviour Horizon already
implements and the harnesses already check. Items work the same way (`"template":
"minecraft:diamond"`, overriding `max_stack_size`, `rarity`, `crafting_remainder` and any
data component in `components`; a block's item takes `components` too).

A block shaped unlike its template declares its own shape (Starling): `"properties": {"shape":
[[0, 6, 0, 16, 10, 16], [5, 0, 5, 11, 16, 11]]}`, boxes in sixteenths as model elements are
(-16 to 32: a block out at most), made for a state facing up (or along y) and turned to each
state's `facing`, else its `axis`, as Create's shapers are. Its outline and collision are
those boxes, and it hides none of its neighbours' faces nor their light (a cogwheel on a
chain's template, a crushing wheel that is a whole block but lets its neighbours show).


A block that keeps items of its own declares the **machine** it is, `"machine": "depot" |
"basin" | "belt" | "burner" | "funnel" | "chute"` (Starling, `machines.json` in the root): its block entity
is a tag the chunk saves (its id its block's), sent to the players near with a Starling-only
block entity type, and its items drop when it breaks (game/machine_entities.rs). Hoppers put into
a depot, a millstone, a basin or a saw and take from their outputs. A `funnel` (its states'
`facing`, `extracting` and `powered`) faces away from the inventory behind it: it puts what comes
in at its open side into it, or extracts and drops what it gives every 8 ticks (one item, a
`brass` one's block up to a stack), while no redstone signal is beside it; a `*_belt_funnel` over
a belt takes what passes off it, or pushes onto it (its `shape`: `pulling`, `pushing`,
`retracted`, `extended`), and a sideways funnel placed over a belt or depot becomes one
(game/funnels.rs). Items fall through a `chute` (its `facing` down, or a diagonal one's way) from
the inventory above or landing on it to the one below, the chute it leads into, or dropped
(game/chutes.rs). A block may also declare `models`, more models the game draws for it in the
order its machine names them (a blaze burner's blaze, rods and flame: `block-models.json`).

A block can also be a **kinetic part** (Starling: rotation passed from block to block, as
Create's; `horizon_client::kinetics`): `"kinetic": { "part": "shaft" | "cogwheel" |
"large_cogwheel" | "gearbox" | "motor" | "crank" | "drill" | "crushing_wheel" | "millstone" |
"press" | "mixer" | "fan" | "water_wheel" | "clutch" | "gearshift" | "belt" | "saw" | "bearing" |
"arm", "rpm": 16,
"spins": true, "half": "<ns>:block/<model>", "extra": "<ns>:block/<model>", "stress": 4,
"capacity": 32 }`. `stress` is what a part takes from its network per RPM it turns at, `capacity`
what a source gives per RPM it turns the network at; a network taking more than its sources give
stands still (Create's stress units). Its axis or facing is its state's `axis`
or `facing` (a shaft-like part with only a `facing`, a water wheel, is an axle along it). A part that turns whole (`spins`) declares `"render_shape": "ENTITYBLOCK_ANIMATED"`
in its properties, so the terrain leaves it to the game, which draws it turning; `half` is a
model drawn turning at each face it joins through (a gearbox's shaft ends), `extra` one turning
with it (a crank's handle), turned as the blockstate turns the block's own model unless
`"extra_facing": "north"` (or another direction) says which way it is made pointing; it is then
turned from there to the state's `facing`. The game draws only the faces of these models that
look at the camera, as the terrain does. Where the game simulates the world (its own server, not a
remote one), a `drill` turned through its back breaks the block it faces and `crushing_wheel`s two
apart turning towards each other crush the items that fall between them, by the content root's
`create:crushing` (else `create:milling`) recipes; a hopper facing the gap fills it
(`game/kinetic_machines.rs`, ported from Create's code, MIT). A `millstone` (a small cogwheel
also joined from below) mills what falls on it or a hopper puts in; a `press` (an axle along its
facing) presses a depot's item two blocks below, items lying under it, or compacts a basin's
(`create:compacting`, and 2x2 and 3x3 crafting); a `mixer` (a small cogwheel) mixes a basin's
two blocks below (`create:mixing`, shapeless crafting, fluids, heat); a `fan` blows or pulls
items along its current and water, lava, fire and soul fire in it wash, blast, smoke and haunt
them (game/processing.rs, basins.rs, fans.rs). A `water_wheel` is a source the water flowing past
it turns, 8 RPM; a `clutch` breaks and a `gearshift` reverses its axle while powered. `head` and
`pole` name the models a press or a mixer moves down as it works. A `saw` facing sideways cuts the
wood, leaves and plants it faces as a drill does and fells the tree above, which tips over away
from it and breaks where it lands (Starling: Create breaks it standing); facing up it is an
axle across it (its `axis_along_first`) cutting the items put on it (`create:cutting`, the
stonecutter's recipes, and the wood recipes Create makes as the game loads), its `models` the
blade's: sideways running, reversed and still, then upright (game/saws.rs). A `bearing` (a
drill's axle behind it, its `models` its top) carries the blocks attached in front of it round
its facing's axis, a windmill one (its id says so) being a source by its sails; an `arm` (a
small cogwheel about y, joined below or, `ceiling`, above; its `models` its parts) moves items
between the points marked with it in hand before it is placed (game/bearings.rs, arms.rs).
The build gathers
the parts in the root's `kinetic.json`.

How the game loads them, without touching vanilla's path:

- `packs::startup_root` keeps prepared tables, disposable caches and resolved resource reads separate.
  Enabled mods' `assets/` and `data/` are lazy layers over vanilla; folders and open jars use the same
  interface. Selected resource packs override the asset view without changing the server's data layers.
  Jar code is never executed, and raw jar entries are not copied into a generated resource tree.
  Content mods still generate per-state tables (`facts.json`, `gameplay-facts.json`,
  `block-behaviours.json`, collision, occlusion and movement tables, `model-states.json`,
  `render-definitions.json`, `items.json`, ...). Mod blocks' rows are appended from their templates,
  with declared overrides. Derived tag merges and rewritten worldgen bundles are generated output.
- **Vanilla state ids do not move.** Mod states are appended after vanilla's, mods in id order,
  so the same mod set gives the same ids. Saves store block names, so ids never reach the disk.
- Loaders that read only `data/minecraft/` (recipes, loot, tags) read every namespace, as
  vanilla does. With no mods there is only `minecraft`, so nothing changes.
- **Namespaces.** A mod's files go under its id, and under the namespaces its manifest lists
  when its Java original ships them so (`namespaces = ["kaisyn", "towns_and_towers"]` for Towns
  and Towers, mod id `t_and_t`; docs/modding/src/how-to/content-mods.md). No namespace has two owners: a mod whose id or
  listed namespace another mod that is on already owns is left out, with both named in the log.
  `horizon-port-pack` avoids that inside a pack: a namespace two carried mods both claim (YUNG's
  structure mods all ship files under `yungsapi`, the namespace of YUNG's API, whose own jar isn't
  carried) is left to none of them, and its files stay outside. The launcher applies the game's
  rule before it starts a pack (`pipeline::loadable`) and lists what it left off.
- Generated tables are built on the first start with a set of mods and kept for later starts. A stamp
  (`horizon-mod-content.stamp`) hashes the game executable, the base tables and every mod file's
  size and mtime. Adding, removing or editing a mod, or a new build of Horizon, rebuilds it. For
  ATM10's 40 data-tier mods the build takes about a minute of the first start on a busy machine.
- **Worldgen.** Mods' structures, structure sets, template pools, processor lists, configured and
  placed features join the `worldgen/*.json` bundles. Structure templates are loaded lazily from
  their original `data/<ns>/structure/` entries. Their biome tags are merged into `worldgen/biome_tags.json`, minus
  the biomes and tags Horizon does not have. Mod biomes, noise and density functions are not
  carried yet.
- **Limits.** Chunk sections size their global palette to the registry: 16 bits for vanilla's
  35,723 states (the same chunks, saves and packets as before), one more bit each time content
  mods double it, up to 2^20 states (1,048,576). Past that the content root is refused with the
  states per mod. ATM10's 42 carried mods take the registry to 193,762 states (18 bits). On the
  network the width is the registry's: unchanged for vanilla clients as long as no content mod
  is on, wider only between Horizons that share the same mods; a Horizon with content mods still
  reads a vanilla server's 16-bit chunks. Block sprites fill texture arrays of 2048 layers, eight
  at most (16,384; vanilla takes 1,250, identical textures share a layer; ATM10's 42 take 9,790).
- **Broken mod files load as vanilla loads them.** A blockstate definition that does not bind
  (a multipart value the block does not have), a block model that is missing or does not parse,
  and a recipe that does not parse are logged and skipped: the block gets no model or the
  missing model, the recipe is absent, everything else loads. Vanilla's own files never hit
  these paths.
- Multiplayer works when the server and its players run the same content mods: a client whose
  mods add different blocks, items, effects, entity types or menus is refused when it joins.
- Not in 0.2: worlds opened without a mod they used (vanilla turns unknown blocks into air; we
  will ask first), vanilla ids redefined by a mod (refused).

## The pipeline: `horizon-port-pack`

A Rust tool in this repo (`crates/horizon-port-pack`, a CLI the launcher also calls), modelled
on the version-port pipeline (`tools/version_port.py`: detect, diff, regen, harnesses, report,
publish). Each step reads and writes files in a work directory, so it can be rerun, resumed and
inspected:

```
<work>/                       ~/.horizon/ports/<pack-slug>/ for players; ~/code/horizon-parity/modports/ for us
├── pack.json                 normalised import
├── inventory.json            per mod: metadata, licence, census, class, tier, deps, layer
├── jars/                     the user's own jars (copied or linked from their instance), never uploaded
├── mods/<id>/
│   ├── carry/                assets/ + data/ upgraded to 26.3
│   ├── oracle/               facts, registries and traces exported from the Java oracle
│   ├── port/                 the agent's Rust crate (tiers logic and up)
│   ├── harness/              per-mod harness results and logs
│   └── <id>.hmod
└── coverage.json, coverage.md
```

**Status.** `import`, `inventory`, `fetch`, `carry` and `report` run today, and `port` runs
them all for what a player's machine can port (content mods of the data tier), as the
launcher's "Import modpack" does:

```
cargo run -p horizon-port-pack -- import ~/Downloads/pack.mrpack ~/.horizon/ports/pack
cargo run -p horizon-port-pack -- inventory ~/.horizon/ports/pack     # --offline reuses modrinth.json
cargo run -p horizon-port-pack -- fetch ~/.horizon/ports/pack         # the portable mods' jars, or name them
#   --from <folder>: copy the player's own jars (an installed instance, a downloads folder)
cargo run -p horizon-port-pack -- carry ~/.horizon/ports/pack         # content mods with a jar, or name them
#   --resources <prepared root>: only templates Horizon's tables have
cargo run -p horizon-port-pack -- report ~/.horizon/ports/pack        # coverage.json and coverage.md
cargo run -p horizon-port-pack -- events ~/.horizon/ports/pack/jars   # NeoForge events the mods listen to, and their hooks
cargo run -p horizon-port-pack -- port ~/Downloads/pack.zip ~/.horizon/ports/pack [--from <folder>] [--resources <root>]
```

### Data packs in mod jars

Some mods are a data pack in a jar: no classes, a `pack.mcmeta` and a `data/` folder (the skyblock
packs of Skyblock Plus are). A content mod may not hold `data/minecraft`, so the carry would drop
what they are for, such as a void world's noise settings. For a 26.2 or 26.3 pack, `port` makes
them data packs instead: upgraded to 26.3 (`docs/datapack-upgrade.md`; a 26.3 one is copied as
it is) into `<work>/home/new-world-datapacks/<mod>/`, with what happened in `<work>/datapacks.json`.
A content mod an earlier port carried from the same jar is removed, and so is a pack in that folder
whose jar is no longer a data-only one of the pack: `port` owns the folder.

`home/` is the profile's game folder. The game copies its `new-world-datapacks/` into each world it
creates there: Create New World shows them selected in its Data Packs screen, and a world made
without that screen (`--world`, the control socket) gets them all. Worlds made before keep what
they have. Without the folder nothing changes.

Before its jar is read, a mod whose Modrinth project also ships as a data pack (`datapack` among
the project's loaders) counts as data tier, so `fetch` gets its jar; the jar then decides. The
report lists these jars as partial: nothing compares them with the Java pack yet, and their
`assets/` (an advancement font, say) are not loaded.

### Resource packs from an imported modpack

Import stages embedded resource packs in `<work>/resourcepacks/`: `.mrpack` common overrides and client
overrides (the client copy wins), a CurseForge ZIP's declared override folder, or an installed instance's
`resourcepacks/` directory. ZIP packs stay intact; directory packs must contain `pack.mcmeta`. Server-only
overrides and unrelated files such as scripts and `options.txt` are not copied.

`port` also obtains client-supported `.mrpack` resource-pack ZIPs from the existing permitted download hosts,
checking the index's SHA-1 before keeping them. `<work>/resourcepacks.json` records available, missing, failed,
conflicting and unsupported entries; they also appear in `coverage.json` and `coverage.md`. A copied pack is
reported as partial, not as a rendering-verified port. Shader packs are reported as pending conversion.
Old import folders without this report still open.

The launcher copies staged packs into `<work>/home/resourcepacks/` on import, port and launch. It preserves any
existing profile pack as a whole, including edits inside a directory pack, and lists name/content conflicts.
`<work>/profile-resourcepacks.json` records those results. A profile with resource packs and no carried mods can
play. Enable packs in the game's Resource Packs screen; importing never changes the enabled-pack list.

Paths must stay within staging, links are refused, and one import is limited to 65,536 resource files and
512 MiB of resource bytes (including both override layers). Indexed downloads are limited to 512 MiB each.
These checks use synthetic packs and temporary profiles; in-game rendering still needs Minecraft 26.3 prepared
resources and has not been verified for this local batch.

`check <jar> <out>` takes one mod jar on its own, as the launcher's mod browser installs it
([mod-browser.md](mod-browser.md)): it carries the jar into `<out>/carry/` and reads its class
files (constant pool, superclass, declared methods; no decompiling) for what the carry can't
take, then writes the verdict to `<out>/check.json`. **Works**: content only, and the code just
registers it. **Partly**: the content ports, and the code features listed don't (block entities,
menus, entities, blocks and items with behaviour of their own, recipe types, Mixins, game events).
**Doesn't run**: nothing to port, or a jar made for 1.20 or older. Each mod class is followed up to
the first game class it extends; a block subclass that only overrides how it looks or is placed
(`getStateForPlacement`, `rotate`...) is registration. Game classes are read by Mojang's names
(26.1 and later, and NeoForge since 1.20.5); older Fabric jars name them in intermediary, so a
class extending one counts as code that can't be read. On ten 26.3 jars (2026-10-22): Macaw's
Fences, Windows and Furniture, Ecologics, Compressed Blocks, More Decorative Blocks and Moog's
Nether Structures are Partly; Sodium and GeckoLib don't run (Mixins, renderers, nothing to port);
Fabric API doesn't run (its id has a dash, which content mods can't use). A check takes 0.2 s to
3 s, and 24 s for Compressed Blocks (18 MB, 9,360 recipes, writing the carry dominates).

`events <jar or folder> [--hooks <hook-counterparts.json>]` reads the same class files for the NeoForge
events a mod listens to and the capabilities it uses. A listener is an `@SubscribeEvent` method's
parameter, or a method reference or lambda that takes one event
(`NeoForge.EVENT_BUS.addListener(this::onTick)`). It looks each name up in the hook catalog's
`neoforge` names, generated at build time from the Rust hook declarations (see the
[hook notes](https://arismoko.github.io/horizon/reference/hook-notes.html)). An optional JSON
file with `hooks` entries containing `name` and `neoforge` can replace those labels for a report.
Over a folder of jars it ranks the names by how many mods use them. Each name gets one of eight answers:

- a hook;
- another phase's hook (`player_tick_post` for `PlayerTickEvent.Pre` when only Post is listed);
- a hook whose label says why it isn't quite the counterpart;
- data: the event is gone because vanilla made what it built into data, and the answer names the
  registries or the item component a port writes instead;
- mod API: no hook, but another part of the mod API, and the answer names the `Registrar` method a
  mod calls from `Hooks::register` or the capability key it asks and answers by;
- load phases: a mod-loading event Horizon has no hook for by design, and the answer says where a
  port does that work instead;
- no hook: nothing in the game would fire one, and the answer says why;
- none.

The load-phase events follow the modding book's
[load phases](https://arismoko.github.io/horizon/concepts/load-phases.html).
`FMLCommonSetupEvent`'s work goes in `Hooks::register`, then the first server reload.
`FMLLoadCompleteEvent`'s goes after the initial config and before `server_about_to_start`.
`FMLDedicatedServerSetupEvent`'s goes in `server_about_to_start`, when its `dedicated` flag is set.
`FMLConstructModEvent`'s goes in `Hooks::register`: the book doesn't name the event, and
Registration is the first phase it gives a mod declarations in.
`InterModEnqueueEvent` and `InterModProcessEvent` carried `InterModComms` messages. A Horizon
dependent calls the library directly instead, after it in dependency order.

Names NeoForge changed after 1.21.1 (`Capabilities.ItemHandler`, `Capabilities.FluidHandler`,
`Capabilities.EnergyStorage`, `AddReloadListenerEvent`, `BlockEvent.BreakEvent`,
`ContainerScreenEvent.Render`, `RegisterColorHandlersEvent.Block` and `.Item`, …) are looked up
under their new ones, and the answer shows the new name. A rename is where a port starts, not a
promise that the event carries the same things: `RENAMED` in `events.rs` says which ones changed
what they carry. `RegisterEvent.RegisterHelper` is the helper `RegisterEvent` hands a mod, so it
gets `RegisterEvent`'s hooks.

The mod API answers are the registration events a `Registrar` method replaces
(`RegisterKeyMappingsEvent`, `EntityAttributeCreationEvent` and `…ModificationEvent`,
`RegisterSpawnPlacementsEvent`, `RegisterTicketControllersEvent`) and the capabilities with no hook
label of their own, which get their key (`mod_api::FLUIDS` for `Capabilities.Fluid.BLOCK`).

`GatherDataEvent` has no hook because data generation runs in the mod developer's build, not in the
game; what it wrote is already in the jar. `IdMappingEvent`, `RegisterNamedRenderTypesEvent` and
`RenderLevelStageEvent.RegisterStageEvent` have none because NeoForge 26.3 no longer has them.

`RegisterBrewingRecipesEvent` is data (`minecraft:brewing` recipe files), and so are
`RegisterDimensionSpecialEffectsEvent` (the `minecraft:visual/*` attributes of a `dimension_type`)
and `FurnaceFuelBurnTimeEvent` (the item's `minecraft:cooking_fuel` component). `VillagerTradesEvent` and
`WandererTradesEvent` are data: 26.1 made villager trades the `trade_set` and `villager_trade`
registries (NeoForge's 26.1 primer), and 26.3's NeoForge has neither event. A port writes each
trade as a `villager_trade` file and adds it to the tag a set reads (`armorer/level_1`'s set takes
`#minecraft:armorer/level_1`). Tags merge, so several mods can add to one level. The files come from
the mod's own data or from `data_pack_files`. The report reads names only, never code: it says
where a port starts, for a human to check.

On ATM10's 498 jars (2026-11-05, 8 s), 416 of 497 mods listen to events or use capabilities: 6,616
uses of 326 names. Upstream's catalog at that date had a hook for 23% of those uses, and 43% once
horizon-rust/horizon#9924 labelled 32 core hooks. The most used names with no hook are mod setup and registration
(`FMLClientSetupEvent` 208 mods, `RegisterPayloadHandlersEvent` 180,
`RegisterCapabilitiesEvent` 162, `RegisterMenuScreensEvent` 143), which a Horizon mod does its own
way. After those come `ClientTickEvent.Post` and `.Pre` (95, 46), `RenderLevelStageEvent` (81) and
`ClientPlayerNetworkEvent.LoggingOut` and `.LoggingIn` (53, 35).

`fetch` gets each jar the player's way, never from us: copied from a folder they have (matched
by SHA-1, or through a CurseForge app instance's `minecraftinstance.json`), else downloaded from
the link the pack itself gives (a `.mrpack`'s, on the format's hosts only) or, for a CurseForge
pack, the same file on Modrinth's public CDN, found by its SHA-1. A jar is kept only when its
hash matches. A file only CurseForge has is listed as "CurseForge downloads coming soon" (its API
needs a paid key; Ludovic, 2026-10-22), with the player's installed instance as the way round it.
`<work>/fetch.json` says what happened to each file. On All the Mods 10 8.3's CurseForge zip
(2026-10-17): of the 54 data-tier content mods, 42 come from Modrinth's CDN (84 MB) and 12 need
the key or the instance; `port` then carries the 42 over (0 ported, 42 partial: the harness is a
dev step).

`inventory` reads metadata only: Modrinth answers by file hash, and the jars only if the user's
instance has them (an imported instance folder, or jars put in `<work>/jars/`). Without jars,
classes come from the reviewed table, Modrinth categories and sides; with jars, from their
`mods.toml` / `fabric.mod.json` and file census too. On Create+ 6.0.0 alpha f (155 files, metadata
only): content 54, library 33, client-ui 26, performance 25, other 14, unknown 2, server-only 1;
40 rows matched the reviewed ATM10 table; three dependency layers (93 / 57 / 5).

`carry` copies a jar's `assets/<id>/`, `data/<id>/`, `data/minecraft/tags/`, `data/c/tags/` and the
sources it adds to vanilla's atlases (`assets/minecraft/atlases/`) into `mods/<id>/carry/`, a folder content mod (API 0.2) the game loads with `--dev-mod`, and
keeps what a content mod may not hold (other namespaces, vanilla data) in `outside/`. Files of
the mod's own content that the game's content loader would refuse whole also go to `outside/`,
listed with the reason in the report's `unreadable`: paths vanilla does not read (upper case),
and JSON that does not parse. Vanilla skips them one by one. A vanilla or convention tag
with `"replace": true` is carried as it is: the game honours it as a data pack's, with a warning
(docs/modding/src/how-to/content-mods.md); Towns and Towers' seven `minecraft:has_structure/*` biome tags are such.
A byte-order mark is dropped. For ATM10's 42 mods that is 6 files in 4 mods, and the 42 load as
carried. No class file is copied. It upgrades from 1.21.1 to 26.3: vanilla-type recipes (ingredients), loot tables
(`conditions` lists become one `condition`, `functions` become `modifier`, kinds move to `type`,
tool matches on silk touch or shears become `minecraft:tool/can_silk_touch` and
`minecraft:tool/can_shear`, and number providers written as a bare `{"min", "max"}` get
`"type": "minecraft:uniform"`), and the `items/` definitions 1.21.4 introduced. 1.21.1 read such
a bare range as uniform and 26.3 refuses it: 304 of ATM10's carried tables have them (rolls,
counts, enchantment levels), and before the carry typed them their chests came out empty or short.

Blocks and items come from the NeoForge oracle when `<work>/oracle/facts.json` exists (step 6):
every block the mod registers gets the vanilla template of the same vanilla class and states
whose shapes, sounds, set type and wood type match best, with the mod's own hardness, blast
resistance, light, tool need, friction, map colour and sounds as overrides. `--resources
<prepared>` limits templates to blocks Horizon's tables have. `carry-report.json` lists, per
block, what the template does not reproduce (other shapes, sounds no vanilla block has, a class
of its own), and the blocks left out: those whose vanilla class has no vanilla block with the
same states (Macaw's garage doors, multi-part gates). An item of a vanilla tool or armour class
(`SwordItem`, `PickaxeItem`, `ArmorItem`, ...) gets the iron item of that class and slot as its
template, and the oracle's durability, attribute modifiers, tool rules, enchantability and repair
items as a component patch over it, minus what the template already has (`--resources` gives the
template's components); other items keep `minecraft:stick`. Armour of the mod's own material gets a
26.3 equipment asset (`assets/<ns>/equipment/<material>.json`) made from its 1.21.1 layers, their
`textures/models/armor/<name>_layer_1.png` and `_layer_2.png` copied to
`textures/entity/equipment/humanoid/` and `humanoid_leggings/`, and its `equippable` names that
asset and the material's equip sound. A material with no asset to name (layers elsewhere, another
mod's) draws the template's armour, reported as a difference. Recipes get the convention tags they use
(`c:dyes/red`), filled from the oracle with vanilla's and the mod's own members. Without the
oracle, templates are guessed from the blockstate's properties: the template whose properties
include them with the fewest left over (models often ignore `powered` or `waterlogged`), the
block's name breaking ties (`_pane`, `_gate`, `_trapdoor`). Walls and vines have the same
property names; sides tested as `true` / `false` make a vine (Chipped's 11 vines, which the game
refused as walls: their blockstates did not load).

### 1. Import

| Format | Read | Jars come from |
|---|---|---|
| Modrinth `.mrpack` | `modrinth.index.json`: `dependencies` (minecraft, neoforge / fabric-loader / forge / quilt-loader), `files[]` with path, sha1/sha512, `env` (client/server), download URLs; `overrides/`, `client-overrides/`, `server-overrides/` | downloaded from the listed Modrinth URLs, hash-checked |
| CurseForge zip | `manifest.json`: `minecraft.version`, `modLoaders[]`, `files[]` (`projectID`, `fileID`, `required`), `overrides`. When the overrides hold Crash Assistant's `config/crash_assistant/modlist.json` (All the Mods 10 does), its jar names, mod ids and SHA-1s replace the bare ids | the user's installed instance (CurseForge app `minecraftinstance.json` + `mods/`), or the same file on Modrinth by SHA-1. CurseForge's API needs a key, so we take what the user already downloaded |
| Prism / MultiMC instance | `mmc-pack.json` components (`net.minecraft`, `net.neoforged`, `net.fabricmc.fabric-loader`); for a CurseForge app instance without one, `minecraftinstance.json` (`gameVersion`, `baseModLoader.name`), else its `manifest.json`; `instance.cfg`, `.minecraft/mods/*.jar`, packwiz `.pw.toml` files if present | the instance folder |
| Prism / MultiMC zip | Root or one enclosing instance folder with `mmc-pack.json` and a game folder | The bundled `mods/*.jar` are copied into the local porting work folder. Java code still needs a port. |
| packwiz | `pack.toml`, `index.toml`, `mods/*.pw.toml` | as listed |
| Crash Assistant `modlist.json` | jar name → mod id, name, version, Modrinth SHA-1; the loader entry (NeoForge `21.1.x` is Minecraft 1.21.1). Packs such as ATM10 publish it in their repository | metadata only; jars put in `<work>/jars/` |

`pack.json` holds the Minecraft version, the loader and its version, each file with its hashes
and side, and the overrides (configs, KubeJS scripts, datapacks).

### 2. Inventory and classification

Per jar, without decompiling:

- **Metadata:** `META-INF/neoforge.mods.toml` / `META-INF/mods.toml` / `fabric.mod.json`: id,
  version, `license`, authors, URLs, dependencies with ordering and side, mixin configs, access
  transformers.
- **Census of files:** blockstates (≈ blocks), item models (≈ items), recipes, loot tables,
  tags, worldgen files, structure NBTs, languages, sounds, textures; the number of mixins and
  the vanilla classes they target; whether the jar has code beyond its data.
- **Census of classes:** the superclass names in the class files (constant pool only): how
  many block entities, menus, screens, entities, renderers, recipe serializers, payload types.
- **Known mods:** a reviewed table in the repo (id → class, tier, Horizon equivalent: "sodium:
  performance, built in", "jei: client-ui, recipe viewer built in") wins over heuristics. It
  starts with ATM10's 495 rows.

Class rules, in order: the known-mods table; client-only side → client-ui; server-only side →
server-only; mixins only, into rendering or ticking, no content → performance; no content and
depended on by others → library; depends on two or more content mods and adds little →
integration; otherwise content. Tier rules: content with no code beyond registration →
data; behaviour callbacks only → logic; block entities or menus → machines; entities,
renderers, dimensions or mixins into gameplay → deep.

### 3. Dependency order

A topological order over required dependencies, libraries first. Each mod gets a layer (0:
needs nothing in the pack). A mod is ported only after its dependencies are ported or mapped
to the API. A library mapped to the API ("Curios → accessory slots") counts as done when that
API feature exists. Cycles (rare: optional mutual integrations) are broken at optional edges.

### 4. Carry-over: data and assets

Mechanical, the same for every mod, and no agent:

1. Extract `assets/` and `data/` from the jar into `mods/<id>/carry/`.
2. **Upgrade to 26.3.** ATM10 is 1.21.1 and Horizon is 26.3. Item models moved to `items/`
   (1.21.4), recipe ingredients and results changed shape (1.21.2), some definitions moved to
   files of their own, and some registries and tags were renamed. The upgrader is a table of these changes generated from
   vanilla's own datafixers and pack-format notes, applied per file. A file it cannot upgrade
   is listed, not guessed.
3. **Registrations.** Block and item ids registered in Java code are read from the oracle
   (step 6): its facts exporter writes each mod block state's hardness, sounds, shapes, light,
   map colour and class chain. These are the same exporters that produce Horizon's vanilla
   `gameplay-facts.json`, run on the modded game. The class chain picks the template (a
   `DoorBlock` → a vanilla door). Without an oracle, the blockstate's property set gives the
   template (`facing, half, hinge, open, powered` is a door), with the template's numbers.
4. **The pack's own data.** KubeJS scripts, Almost Unified and config-driven recipes change
   recipes, tags and loot after load. We do not translate scripts. The oracle exports the
   **final** recipe, tag and loot registries of the whole pack once, and the pack layer
   carries those over.
5. Write `<id>.hmod`. For a data-tier mod, it is now ported.

Two cases the oracle fills in:

- **Loot registered in code.** Chipped ships 7 loot tables for about 7,000 blocks; the rest
  drop themselves through Java code. When a declared block has no table in the jar and the
  oracle shows vanilla's drop-self, carry writes that table in 26.3's shape. When only the
  states with one property value drop it (a door's lower half), the entry gets vanilla's
  `match_block` condition. Chipped: 6,843 tables added.
- **Worldgen carry-over.** Structure libraries give vanilla's types other names. Carry maps
  these to vanilla's:
  - `lithostitched:jigsaw`, MoogsStructureLib's and Repurposed Structures' generic jigsaws
    become `minecraft:jigsaw`;
  - their `advanced_random_spread` becomes `minecraft:random_spread`;
  - their versioned, legacy and empty pool elements become vanilla's; Lithostitched's
    `limited` and `guaranteed` elements are the game's own (its `delegating` places its
    `delegate`).

  Three more rewrites make the mapped structures decode and start where their mod would:
  - **Block states.** 1.21.1 writes a block or fluid state as `{"Name", "Properties"}`, 26.3
    as `{"id", "properties"}` and refuses the old shape, which failed the whole processor
    list, feature or pool. Carry rewrites them (#816; 1,005 files in 17 of ATM10's mods).
  - **Start and placement rules** (#820 in the game, #821 in carry). Repurposed Structures'
    and Moog's jigsaws refuse to start in liquid and check biomes and terrain height in a
    radius; their spreads keep a minimum distance from the world origin and away from other
    sets (named by a structure set tag). Carry writes these under `horizon:start_checks`,
    `horizon:min_distance_from_world_origin` and `horizon:exclusion_zone`; the game runs them
    (`horizon-world`'s `structure/start_checks.rs`). Vanilla data has none of the keys. Moog's
    also spreads its structures 1.65 times as far apart as its files say, which carry now
    applies. MVS went from 829 starts to 90 in a 128×128-chunk square (seed 1234): 294 from the
    spacing, the rest from the start checks.
  - **Mo' Structures** (LGPL-3.0; 38 files). Its `mostructures:generic` is vanilla's jigsaw
    that starts only where the terrain under the 5×5 chunks around it varies by no more than
    its `heightRange`: carry writes `minecraft:jigsaw` with `horizon:start_checks`
    (`terrain_radius` 2, `terrain_range`). Its placement `mostructures:type` takes spacing and
    separation from the mod's config, not its files; carry writes the config's defaults
    (keyed by `config_key`) and the sets it avoids within 3 chunks as `horizon:exclusion_zone`
    with `"their_zones": false`: like the mod, the game tests those sets by their spread and
    frequency alone, not by their own exclusion zones. Its two block-ageing processors
    (`jungle_rot_processor`, `simple_cobblestone`, 3 uses) are still dropped, as is its
    mixin that keeps lakes out of its structures. Over chunks -64..63 that adds 13 starts at
    seed 1234 (pirate ships, churches, a tavern, the castle in the sky...) and 16 at seed 2,
    and every other start stays as it was.
  - **Processors written in Java** are taken out of their lists (#822). The game, like
    vanilla, refuses a list holding a type it does not know, and with it every pool naming the
    list. The structures now generate undecorated (no pillars under them, spawners as the
    template has them); 1,427 processors of 146 types in ATM10's mods, the most common
    `lithostitched:block_swap`, Formations' `biome_replacements` and Repurposed Structures'
    pillar, fluid and void processors.
  - **Spawner processors** carried as data (`horizon-port-pack/src/processors.rs`). Most
    chests in the mods' templates already name their loot table; what the Java processors add
    is the spawners' mobs. Moog's and Repurposed Structures' spawner randomizing processors
    become `horizon:spawner_mobs` (a weighted mob per spawner, picked with the placement's
    random as theirs do, and the spawner NBT they write; Repurposed's `rs_spawners` lists are
    written in). YUNG's Better Dungeons and Better Desert Temples turn a spawner or a
    placeholder block (gravel, bone block, yellow wool...) into a spawner of a fixed mob: that
    is vanilla's `rule` processor with an `append_static` block entity. Moog's vanilla loot
    swap acts only when a "replace vanilla" preset is on, and they ship off. Moog's trial
    spawner and vault processors keep the block and change its block entity: one `rule` per
    block state, with the game's `horizon:edit` modifier, which takes out the state the
    template was saved with (a vault saved with `state_updating_resumes_at` far in the future
    never opens; a spawner's saved `spawn_data` blocks its own mobs) and merges in the
    spawner's normal and ominous configs (by id: the carry upgrades `trial_spawner/` files'
    mobs to 26.3's `equipment`) or the vault's loot table and key. Better Desert Temples'
    placeholder blocks (orange, red and white glass, blue and yellow concrete, red wool,
    polished diorite, blank pots) become what its processors make of them: the fixed swaps as
    vanilla's `rule`, the random ones (suspicious sand, sand and sandstone, upside-down stairs,
    cobwebs, sherds on the pots) as the game's `horizon:pick`, on the same `nextFloat` as the
    mod. Better Dungeons' small dungeons keep one chest and each other one with a fifth's
    chance, two at most (the game's `horizon:count_cap`, counted per placement as the mod's
    DungeonContext is): 12 chests in five small dungeons at seed 1234 become 6.
    Lithostitched's processors (all in ChoiceTheorem's Overhauled Village in ATM10) are the
    game's own types, read as the mod writes them. `block_swap` keeps the properties the new
    block can have: a farm's ripe wheat becomes ripe carrots, but beetroot, whose age stops at
    3, keeps its default; a target block the game does not have (most are Nature's Spirit's and
    Croptopia's) leaves the block as it is. `reference` runs the lists it names, `condition`
    tests the template's block or the world's, `apply_random` and `set_block` draw per block or
    per piece as the data says. Lithostitched's own random is not known yet, so the shares of a
    random choice are the Java pack's but the blocks chosen differ. Lists named by tag and state
    providers other than simple and weighted ones are dropped and counted (ATM10 has none).
    CTOV's compat hooks for other mods (its `modular_compat`, 30 of them in 17 lists) become a
    `reference` when the mod they name is ported along, and are taken out (a no-op, as in the
    mod) when it is not. In ATM10 they all name Nature's Spirit, which the pack does not have.
    Lithostitched's `add_template_pool_elements` and `add_processor_list_processors` modifiers
    (CTOV's houses for 11 of ATM10's mods) become the game's additions, when the mods their
    load conditions name are ported along. The houses are `limited` (at most once in a
    village) or `guaranteed` (tried first, from the depth they name, until placed): the game
    keeps both.
    In Java, Lithostitched also lays out every jigsaw structure its own way (villages,
    outposts, trial chambers; CTOV's villages are `lithostitched:jigsaw`, carried as vanilla's
    jigsaw). Horizon keeps vanilla's layouts, so with Lithostitched in a pack, structure layouts
    differ from the Java pack's for the same seed (their positions do not).
    The processors that build outside their template are carried too: Repurposed's and
    Moog's pillar processors become the game's `horizon:pillar` (a column from a placeholder
    block down to the ground, with the processor list they run on each of its blocks written
    in), Repurposed's bottom pillars `horizon:bottom_pillar`, their fluid fix (a wall of the
    structure's block over water and lava sources next to its open blocks)
    `horizon:close_off_fluid_sources`, and YUNG's pillars (Better Fortresses, Better Jungle
    Temples) and Better Fortresses' stair supports `horizon:yung_pillar` and
    `horizon:stair_pillar`. They write only in the chunk being generated, as the mods do.
    Dropped processors went from 570 to 456 in Repurposed Structures (its pillars, bottom
    pillars and fluid fixes: 242 lists), 14 to 1 in Moog's, 10 to 5 in Better Fortresses and
    52 to 50 in Better Jungle Temples; the structure starts are the same (382 starts, 37,451
    pieces in chunks -64..63, seed 1234). Around spawn at seed 1234, 1,515 blocks change: the
    382 red glass placeholders under Repurposed's ocean outpost and pyramids become prismarine
    columns, and their gravel and prismarine pillars reach the sea floor. In the Nether, the
    Better Fortresses fortress at chunk (-23, 9) stands on its pillars: its terracotta
    placeholders become nether bricks and 41,487 blocks of air (and 2,163 of lava) under it
    become brick and magma columns down to the netherrack, 64,568 blocks changed in its 180
    chunks (the huge fungi there grow around the columns).
    Better Ocean Monuments' ten processors are carried as well, so its monuments are no longer
    dry: its templates are mostly air, which its air processor turns to water below the sea
    level (the game's `horizon:flood_air`); its waterlog processor (`horizon:waterlog`)
    waterlogs what can be and marks the water on the chunk's edges for postprocessing, its
    structure void keeps the world's block (`horizon:keep_world_block`), its placeholder
    blocks become slabs, sponges, seagrass, gravel and aged copper (vanilla's `rule`, and
    `horizon:pick` with a new `nextFloat` for each chance, as the mod draws), and its legs and
    Better Witch Huts' log and fence legs are `horizon:yung_pillar`. In the monument at chunk
    (2, 8) (seed 1234), 318,512 blocks of air become water and none is left between y 30 and
    60 (227,034 before); its 5,142 placeholder blocks are gone.
    Repurposed's opposite fix, which walls off the air and other liquids beside its ocean
    mineshafts' water, is `horizon:close_off_air_sources` (its 4 lists). It runs in the mod's
    order, so the walls it builds keep the later blocks of the template from the mod's "where
    the world is air, keep it" rules: around the ocean mineshaft at chunk (-18, -54), seed
    1234, 650 blocks of air and cave air become prismarine and 614 more template water blocks
    stay water (1,303 blocks change in its 81 chunks).
    Its mineshafts' sky view processor (71 lists) is `horizon:mineshaft_sky_view`: a block
    of the template at or above the world's `OCEAN_FLOOR_WG` height in its column is not
    placed, so a mineshaft cut by a valley or a ravine is not built in the open, except
    plain rails over a block that can occlude, which stay (waterlogged where the world holds
    water). Repurposed's dropped processors go from 253 to 182.
    Still taken out: Formations' biome replacements, blocks aged or propped up.
    In the 128×128-chunk square (seed 1234), every spawner of a mod structure now has its mob:
    in the Overworld 83 Better Dungeons spawners held the template's placeholder pig and 17 of
    Moog's were empty (763 spawners with a mob, up from 628); in the Nether the 52 empty ones
    in Moog's Nether Structures are filled (162, up from 110). Chests are unchanged: 2,777
    and 1,405 with a loot table. The game read loot tables from `data/minecraft/` only, so every one of
    those chests naming a mod's table opened empty; it now reads every namespace, and an
    integer field written as a float (`"rolls": {"min": 3.0, ...}`, as Towns and Towers
    writes them) counts as vanilla's int codecs count it. Of the 675 chest and other
    non-block tables in ATM10's carried mods, 534 now fill a chest (seed 1; none before).
    Repurposed's structure voids keep the world's block, as vanilla's `minecraft:block_ignore`
    does (its 82 lists: mineshafts, the ocean and swamp villages, the ocean and taiga temples,
    the jungle pyramid's hidden room). Before, the game placed them like any template block:
    around the ocean mineshaft at chunk (-18, -54), seed 1234, 974 structure voids took the
    place of 464 prismarine blocks of its walls, 225 of water (dry holes in the sea), 279 of
    air and cave air and 6 rails and walls.
  - **Rule tests** written in Java. Repurposed Structures' mineshafts and Nether monument test
    blocks with three of the mod's own rule tests inside vanilla `rule` processors: what a
    block is made of (solid, liquid, air, with rails and chains), a chance over the distance
    from the template's origin along one axis, and a world height range. The game runs them
    as `horizon:matter_phase`, `horizon:piece_origin_axis_aligned_linear_pos` and
    `horizon:y_value` with the mod's fields, and carry renames them (213 in 75 lists).
  - **Waterlogging.** Repurposed's `waterlogging_when_replacing_water_processor` (the bottom
    pillars of its villages and outposts, 16 lists) is `horizon:waterlog_in_world_water`: a
    block that can be waterlogged is where the world holds water, dry where it does not, and
    one placed in water gets a block tick. Its dropped processors go from 370 to 253 (with
    the structure voids carried); around the ocean village at chunk (12, 10), seed 1234, 6
    spruce fences of its pillars under the sea are now waterlogged.
  - **Namespaces besides the mod id.** Towns and Towers (mod id `t_and_t`) ships all 60 of its
    structures under `kaisyn` and `towns_and_towers`, which carry used to leave in `outside/`.
    Carry now claims a namespace for the mod when the mod's own files (its id's, its tag
    additions and the namespaces already claimed) name ids in it, and no mod of the pack has
    it as its id; it lists them in the manifest's `namespaces` (docs/modding/src/how-to/content-mods.md). Files for mods
    it supports (CTOV's `wares` and `monobank`, YUNG's `morevillagers` tags) and configs of
    pack mods (`cristellib`) stay outside: of ATM10's 42 jars only T&T claims any. A tag of a
    mod's own namespace that `replace`s is carried as an addition (no pack before it defines
    it). In the 128×128-chunk square T&T has 7 starts at seed 1234 (its ocean wreckages, an
    ocean village and outpost) and 7 at seed 2 (forest and snowy taiga villages, snowy
    outposts), from none.
  - **Renamed ids.** 26.3 calls 1.21.1's chain the iron chain (its datafixers rename it in
    worlds). Carry renames it in recipes, loot tables and worldgen files (112 files in 5 mods:
    Repurposed's mineshafts, Better Dungeons' processors, Regions Unexplored's hanging sign
    recipes...), which otherwise fail to load in 26.3. With both, the 5 Nether mineshaft pools load: 47 of
    Repurposed's Nether mineshafts in the 128×128-chunk square (seed 1234), under the lava sea.
  - **Advancements.** An `enter_block` criterion names its block as `blocks` in 26.3; 26.3
    skips 1.21.1's `block`, so the criterion matched any block the player entered. Carry renames
    it (20 advancements in Regions Unexplored: "Downer", "From the Tree Tops" and "Light as a
    Frog" were granted on the first dive into the sea, and its boat recipes' "in water"
    criteria).
  - **Big templates** (#838). Vanilla reads structure templates with no limit on their tag
    count; Horizon now does too (`nbt::Limits::templates`). Seven of ATM10's 8,962 carried
    templates are past the old 1,000,000-tag cap: YUNG's monument start, four When Dungeons
    Arise main pieces and two Nullscape pieces. They used to load as empty templates, so their
    structures never started.
  - **Additions to other sets and pools** (#832 in the game, #833 in carry). A set or pool file
    holding `horizon:add_to` appends its entries to the sets or pools it names (docs/modding/src/how-to/content-mods.md).
    Carry writes these from lithostitched's `add_structure_set_entries` and
    `add_template_pool_elements` modifiers whose load conditions hold for the mods ported
    along, and from CTOV's Java registration: its 21 village types and 11 outposts join
    vanilla's `villages` and `pillager_outposts` with the mod's default weights.
  - **YUNG's API** (#839, #846 in the game; #840, #847 in carry). `yungsapi:yung_jigsaw` and its
    elements become vanilla's jigsaw and single element, with their rules under
    `horizon:yungsapi`. The game assembles them as YUNG's `JigsawManager` does: priority
    pieces, caps by name, depth ranges, `ignore_bounds` and the conditions tree, with
    `piece_in_range`. Dead-end pools swap a piece that got no child for one of its dead-end
    pool, and once the layout is done each piece's modifiers can turn it into another template
    (`transform`) or place it last (`delay_generation`). Better Fortresses' bridges need all
    three: over seed 1234's Nether chunks -64..63 it goes from 3,765 to 4,106 pieces. YUNG's
    placements become `horizon:` keys on a random spread: `horizon:exclusion_zone` for the
    enhanced exclusion zone, `horizon:avoid_biomes` for the temples' ocean and river search,
    `horizon:ring_sections` for Better Strongholds' rings. `horizon:disables` on a YUNG
    structure turns off the vanilla type its mod's mixin turns off. It is written only when
    the game can start the replacement, so vanilla mineshafts stay while Better Mineshafts (a
    Java type) can't.
  - **Repurposed Structures' and Moog's own assembler** (#850 in the game, #851 in carry). Both
    lay out their jigsaws with `PieceLimitedJigsawManager`, not vanilla's. Their structures, the
    Nether variants too, get `horizon:piece_limited`: `y_allowance`, burying, the pools whose
    fallbacks ignore the bounds, liquid, the Nether land search and ledge, and each
    structure's piece caps and required pieces from the mod's `*_pieces_spawn_counts` files.
    The game assembles them the mods' way and runs their post-layout steps (centring,
    burying, the Nether land search).
  - **Enhanced terrain adaptation.** YUNG's API and MoogsStructureLib add a kernel of their
    own to the Beardifier: its own size and falloff, carving or burying above and below each
    piece's floor. Carry writes it as `horizon:enhanced_terrain_adaptation` on the structure
    and on pool elements with their own (docs/modding/src/how-to/content-mods.md), and the game sums it after vanilla's
    terrain density. In seed 1234's terrain before structures are placed, Better Fortresses'
    pieces held 39 to 41 % netherrack and now 3 to 7 %, the mod's open bridges; Moog's mega
    fortress band 45 % and now 30 %; Better Strongholds' pieces, buried, go from 92 to 97 %
    solid to 99 %, closing the caves that cut through them.


  Each mod's `carry-report.json` lists what was mapped, the rules and processors lost by name,
  and the types left as they are. NeoForge's convention biome tags (`#c:is_forest`, ...) come
  from the loader jar (`<work>/loader/neoforge-<version>-universal.jar`, fetched dev-only and
  SHA-1 checked) and are written into the carry. The game skips the structures it cannot
  decode.

  On ATM10's 42 data-tier mods with a jar (seed 1234, chunks -64..63, `chunkgen_bench
  --starts` over the carried worldgen): 286 starts with 15,097 pieces, 150 of them vanilla's
  (unchanged), and no pool that fails to decode (65 before #816 in the 64×64 centre).
  - 1,061 files were mapped (MVS 413, MNS 210, MSS 157, MES 110, Repurposed Structures 104,
    ChoiceTheorem's Overhauled Village 66), and 103 convention biome tags written.
  - When Dungeons Arise, Structory and Towns and Towers use vanilla's types already (T&T's
    namespaces are carried since the namespaces rule above).
  - Still lost, written in Java:
    - Repurposed's mineshafts, mansions and monuments, Better Mineshafts and two Better
      Dungeons types: Java structure types;
    - the block processors written in Java
      (YUNG's banners and decorations, Better Strongholds' legs, Lithostitched's block swaps);
  - **Formations** (Overworld and Nether: 50 structures, 128 pool elements) places one
    template per start at a height found in the noise columns under its corners and centre: on
    the surface, on water or lava, or in a cave (on its floor, under its ceiling, buried in
    stone, on a lava lake). Carry writes its `formations:simple` as the game's
    `horizon:formations` (`horizon-world`'s `structure/formations.rs`, which reads the blocks
    of ChunkGenerator.getBaseColumn through the structure context) and its pool element as
    vanilla's with its `ground_level` under `horizon:ground_level`. In chunks -64..63 that adds
    39 Overworld and 672 Nether starts at seed 1234 (51 and 643 at seed 2), and leaves every
    other start as it was. Its processors (biome replacements, aged blocks, bed colours,
    plants) are still dropped, so its structures keep their templates' blocks.
    Its one PiecedStructure, the fountain, starts the same way and then lays out the element's
    jigsaw children with vanilla's jigsaw: carry writes it as `horizon:formations` with
    `horizon:pieced` (`max_depth`, `max_distance_from_center`), and the game's assembler takes
    the placed start piece (`jigsaw::add_children`), the children kept within that distance of
    the start's centre, one block above the height found. It shares Formations' "uncommon"
    structure set, so where the set now picks it, it takes the place of a statue or a house:
    1 fountain at seed 1234 and 3 at seed 2 in chunks -64..63, one with a child piece.

  With every structure PR above, the same square (seed 1234, chunks -64..63) holds 362
  overworld starts with 22,026 pieces. CTOV has 7, Better Dungeons 72 and Better Ocean
  Monuments 3, and vanilla's monuments are gone as YUNG's mod has them. In the Nether there
  are 512 starts, up from 322: Moog's Nether Structures 147, Repurposed's Nether structures
  40, Better Fortresses 7, with no vanilla fortress. Over chunks -256..255: Better Strongholds 10
  (vanilla 0), Better Jungle Temples 5, Better Witch Huts 11. Vanilla's own worlds are
  unchanged: the structure-start oracle still matches 35 of 35.

  Repurposed's Nether city, Nether shipwrecks and End stronghold are its generic jigsaw with
  one more start check each, carried as `minecraft:jigsaw` with the check named in
  `horizon:start_checks.repurposed`: open air from sea level + 20 to + 45 around the city's
  chunk, no solid block in a 33×30×33 grid over a shipwreck, and land 45 blocks up at nine
  points 35 and 70 blocks apart for the stronghold. Over chunks -320..319 in the Nether there
  are 2 cities and 45 shipwrecks (30 and 865 without the checks); the End stronghold keeps
  8,000 blocks from the centre, and chunks 500..1139 × -320..319 hold 2 (43 without).

  In a world with the 40 mods, seed 1234, `/locate structure mvs:azelea_house` finds one 27
  blocks from spawn and it stands there as the template builds it; When Dungeons Arise's
  bandit towers and Structory's chapel locate too.

### 5. Code: one agent per mod

For tiers logic, machines and deep, in dependency order, as many agents at once as the AI
budget allows:

- **Input:** the inventory record, the carried-over data, the oracle's exports and traces, the
  harness, [modding/src/how-to/native-mods.md](modding/src/how-to/native-mods.md), the ports of its dependencies, and the mod's public
  documentation. Never its code: the agent doesn't decompile, read or quote it.
- **Output:** a native mod, a horizon-mixins bundle started from
  [horizon-native-mod-template](https://github.com/horizon-rust/horizon-native-mod-template), and its `.hmod`.
- **Loop:** write → build → run the harness → read the differences → fix, until the harness
  passes or the agent reports what blocks it. Usually that is a place in the game's code the
  mixins can't reach yet, which becomes an issue ("needs a scheduled-tick hook point"), the way version ports
  turn differences into work items.
- **Rules:** the agent writes the port from observed behaviour, the harness and the mod's
  own data files only; ports follow the mod's licence ([Licences](#licences)).
  Players without an AI agent get the carry-over tiers. A port the licence lets us publish can
  be downloaded instead of regenerated.

### 6. The Java oracle and per-mod harnesses

The oracle is **dev-only**, like Horizon's vanilla oracles in `tools/`: the pack's own
Minecraft version (1.21.1 for ATM10) with NeoForge or Fabric, the mod and its dependencies,
plus a small exporter mod (written by us, never shipped to players). It runs headless and is
driven over a socket, as the vanilla oracles are.

A **harness per mod**, generated from the tier:

| Tier | What is compared, oracle vs Horizon with the port |
|---|---|
| data | every registered block state's facts (hardness, sounds, shapes, light, map colour, drops via loot), every item's facts, every recipe's result for its inputs, loot table outputs over fixed seeds, tags; structure placement over fixed seeds and chunks |
| logic | scripted interactions: place, use, break, tick N times; the world diff and the inventories after each step |
| machines | a fixture world with the machine, its inputs and power: the output, energy and progress per tick over N ticks; the menu's slots and data values; NBT after save and load |
| deep | entity scenarios (spawn, tick N, positions and states, drops), and render captures where the look is the point, compared as images with a tolerance |

The comparison skips vanilla 1.21.1-versus-26.3 differences: it normalises ids and components
through the step-4 upgrader and compares only the mod's own ids and effects.

**Status: the data-tier harness runs.**

```
python3 tools/neoforge_oracle.py export --jars <mods> --deps <their libraries> --out <work>/oracle/facts.json
cargo run -p horizon-port-pack -- carry <work> --resources .local/horizon-client/26.3
python3 tools/mod_port_harness.py --work <work>      # or --jars/--deps to export first
```

- `tools/neoforge_oracle.py` installs a NeoForge server (21.1.259, ATM10's) under
  `.local/neoforge-oracle/`, builds the exporter mod in `mods/horizon/src/neoforge-oracle/` (our code, dev
  only), starts the server headless with the jars and writes, for every block of the mods'
  namespaces and every vanilla block: the class chain, states, per-state hardness, light, tool
  need, map colour, sounds, outline and collision shapes; drops for hand, diamond tools, shears
  and silk touch; placement on a floor and a wall; BlockSetType and WoodType. Then items (class,
  stack size, rarity, food; every default data component in 1.21.1's form, the effective attribute
  modifiers, enchantability and repair items; armour's slot, defense, toughness, knockback resistance,
  equip sound and texture layers), recipes (type, result, count, resolved ingredients) and tags. One run
  with the seven mods below takes about 30 s.
- `crates/horizon-client/examples/mod_port_probe.rs` builds the content root from the carried
  mods and dumps what Horizon's loaders make of the same blocks, drops, recipes and tags.
- `tools/mod_port_harness.py` compares them per mod (blocks, properties, sounds, shapes, drops,
  placement against the template's in the oracle, vanilla tags, recipes, items) and writes
  `<work>/mods/<id>/harness/result.json`. It maps 1.21.1 sound events to 26.3's through the
  vanilla blocks both versions have (`block.metal.*` became `block.iron.*`) and ignores vanilla
  items 1.21.1 did not have (pale oak in `#minecraft:logs`).

The oracle needs the mods' jars, so it is not a `tools/parity.py` harness: it runs where the
user's jars are, and its facts and results stay in the work folder. The first real mods
(ATM10's own jars from Modrinth, all MIT; checks passed / compared):

| mod | blocks | properties | sounds | shapes | drops | placement | tags | recipes | items |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Macaw's Trapdoors 1.1.5 | 179/179 | 11456/11456 | 11456/11456 | 11456/11456 | 10024/10024 | 358/358 | 534/534 | 191/191 | 191/191 |
| Macaw's Doors 1.1.5 | 239/245 | 15296/15296 | 15296/15296 | 12352/15296 | 13384/13384 | 478/478 | 941/941 | 257/257 | 251/257 |
| Macaw's Fences and Walls 1.2.1 | 150/180 | 4800/4800 | 4800/4800 | 4032/4800 | 33600/33600 | 300/300 | 432/432 | 222/222 | 150/180 |
| Macaw's Paths and Pavings 1.1.1 | 234/315 | 4602/4602 | 4602/4602 | 4472/4602 | 6734/6734 | 468/468 | 416/416 | 315/315 | 234/315 |
| Glassential-renewed 3.4.7 | 105/114 | 5177/5177 | 5177/5177 | 4727/5177 | 6447/6447 | 210/210 | 105/105 | 143/143 | 106/115 |
| Factory Blocks 1.4.0 | 42/49 | 42/42 | 0/42 | 42/42 | 294/294 | 84/84 | 42/42 | 1/1 | 42/49 |
| Cloud Glass 1.1.0 | 16/16 | 16/16 | 16/16 | 0/16 | 112/112 | 32/32 | – | 31/31 | 16/16 |
| Chipped 4.0.2 | 6857/6981 | 46212/46443 | 46443/46443 | 46396/46443 | 149093/149093 | 13548/13714 | 11984/12378 | 6/13 | 6849/6973 |

What fails is what API 0.2 cannot express yet: shapes of their own (Japanese doors, hedges,
paths a sixteenth high, glass without collision), sound events of the mod's own
(`factory_blocks:metal_sound`), and blocks whose vanilla class has no vanilla block with the
same states (garage doors, double gates, engraved and facing paths, fans). Every drop, recipe
and tag of the declared blocks matches. Chipped's 124 missing blocks are its own classes (workbenches and
`DirectionBlock`), and its workbench recipes need those blocks. Its drops match since carry writes
the self-drop tables it registers in code (step 4).

### 7. Coverage report

`coverage.json` and `coverage.md`, per mod and totalled per class and tier:

- **ported**: `.hmod` built, harness green;
- **partial**: `.hmod` built, harness passes the listed parts (e.g. blocks and recipes yes,
  machine processing not yet), with the failing checks and the API gaps blocking them;
- **not yet**: waiting on an API tier or a dependency, which is named;
- **not needed**: performance, library mapped to the API, pack tooling folded into the
  pipeline, client-ui built in.

Plus the licence summary (how many ports could be published) and, for a pack, "playable?":
whether every required content mod is ported or partial with its blocks and items present.

`horizon-port-pack report <work>` writes the per-mod rows and the class, tier and licence totals from the inventory, each mod's `carry-report.json`
and its harness result. A data-tier mod is **ported** when its harness is green and nothing was
left out (blocks with a class of their own are counted and named, since facts cannot show
their extra code); **partial** with the failing checks, the blocks left out and what the
templates miss; **not yet** with the API tier it waits for, or the dependency; **not needed**
for libraries, performance mods, pack tooling and what Horizon has built in. Unclassified mods
(the 20 CurseForge-only rows the reviewed table only guesses) count as not yet. A mod made for
1.20 or older (its `recipes/` and `loot_tables/` folders named as before 1.21, which 26.3 does
not read) is carried with its data files moved to 1.21's folder names (`recipe/`, `loot_table/`,
`tags/block/`..., counted as `folders_renamed`); a file the jar also holds under the new name
keeps that copy. Their JSON stays 1.20's: a recipe result naming its item as `item` (before
1.20.5), which 26.3 skips, is kept as it is and counted as `recipes_old_result`, and NBT in loot
functions, ingredients and predicates is not upgraded yet (#10262). In the game each such file
fails alone and the rest load: those recipes are skipped, `set_nbt` and `copy_nbt` drop their item
without the NBT, an advancement's NBT predicate matches any item, a template's block renamed since
1.20 is air, and a 1.20 command in a function fails. Such a mod is partial whatever its harness
says, with that in its reason. `check` still says it doesn't run.

Both files open with a plain headline for players, counted from the rows' own status, class and
tier: how many of the mods that need porting came over (ported or partial, as content: blocks,
items and structures, never the mod's own code), how many of the rest `port` can still carry
over, how many need mod API the game doesn't have yet, and how many aren't sorted yet. Resource
packs and shader packs aren't counted as mods. Each row also has its reason in plain words
(`plain` in `coverage.json`, the last column of `coverage.md`, above the technical line on the
Modpacks page), next to the unchanged technical `reason` for modders. The launcher words the
headline through its translations; the sentences per row are English, like the reasons.

**ATM10, measured** (`import` of ATM10's `modlist.json` from its repository on 2026-10-16, 496
files; `inventory`; `carry` and the harness on the eight mods we downloaded; `report`):

| class | ported | partial | not yet | not needed | all |
|---|---:|---:|---:|---:|---:|
| content | 1 | 7 | 268 | 0 | 276 |
| library | 0 | 0 | 0 | 77 | 77 |
| integration | 0 | 0 | 40 | 3 | 43 |
| client-ui | 0 | 0 | 27 | 2 | 29 |
| other | 0 | 0 | 1 | 23 | 24 |
| unknown | 0 | 0 | 20 | 0 | 20 |
| performance | 0 | 0 | 0 | 16 | 16 |
| server-only | 0 | 0 | 11 | 0 | 11 |
| **all** | **1** | **7** | **367** | **121** | **496** |

By tier, the 367 not yet: data 57 (carry-over and the harness, no agent: their jars were not
downloaded), logic 66, machines 97, deep 92, client 35, unclassified 20.
Ported: Macaw's Trapdoors. Partial: Macaw's Doors, Fences and Walls, Paths and Pavings,
Glassential, Factory Blocks, Cloud Glass, Chipped (see the harness table) and MVS, whose
structures now generate (see step 4). Of the 9, 7 are MIT, one LGPL and Chipped is under the
Terrarium License; nothing is published.

## Measuring "10x"

`tools/perf_bench.py` already measures Horizon against vanilla and vanilla with performance
mods on the same machine, world and camera path ([benchmark.md](benchmark.md)). With
`--game neoforge --mod-jars <dir> --deps <dir>` it runs the mods on their own loader (NeoForge
21.1.259 for ATM10, installed under `.local/neoforge-oracle`, `-Xmx2G` like the launcher),
driven by the same steps through a dev-only NeoForge port of the bench mod
(`mods/horizon/src/neoforge-bench`). `--game horizon --port-work <work>` loads a work folder's
carried-over mods into Horizon. A whole pack (`--pack`, its recommended JVM arguments) is next.

| Metric | How | Horizon side |
|---|---|---|
| **Load time** | start → title screen; start → in a fresh world, every chunk around the spawn drawn | the same with the ported pack's `.hmod`s enabled |
| **RAM** | peak and steady RSS of the process, sampled 4 times a second from outside (the whole JVM for Java) | the whole process |
| **FPS** | the four flight scenes: mean, 1 % and 0.1 % lows, p99 frame time | same |
| **TPS / MSPT** | a fixed server-load world: N loaded chunks with the pack's machines and mobs placed by the harness fixtures; mean and p99 milliseconds per tick over 60 s (NeoForge: `/neoforge tps` and spark; Horizon: the integrated server's tick times, which today feed only the debug chart, exposed through `horizon-ctl`) | same fixture, the ported content |
| **World generation** | chunks per second pregenerating a fixed square (Chunky on NeoForge; Horizon gets a pregeneration command for this) with the pack's worldgen | same |
| **Disk and download** | install size of the pack against its `.hmod`s | |

Two comparisons, both published:

1. **Same content.** NeoForge with only the mods Horizon has ported (plus their dependencies)
   against Horizon with those ports. Content matches, so this is the honest ratio.
2. **What players run today.** The full pack on NeoForge as a reference row, labelled as
   such, beside Horizon's partial pack. This is not a like-for-like ratio.

"10x" is claimed per metric only where the same-content ratio reaches it over the repeats'
confidence interval. Other ratios are reported as they come out. Caveat (in every report):
the pack runs Minecraft 1.21.1 and Horizon runs 26.3, so the vanilla parts differ by a few
versions.

### Measured: six ported mods against the same mods on NeoForge

Cloud Glass, Factory Blocks, Glassential, Macaw's Fences, Paths and Trapdoors (Doors left out:
with Trapdoors it passes the block states chunks hold, see Limits), carried over and loaded as
dev mods in Horizon, against their jars plus Architectury and Fusion on NeoForge 21.1.259.
Mac mini M4 Pro, 1280x720, seed 1234, the four flight scenes, 2 games per row, 2026-10-17.
Means; FPS is the mean of the four scenes. "Title" is start to title screen, "world" start to
a fresh world drawn around the spawn, "scene load" a teleport to every chunk drawn.

| RD | game | title s | world s | scene load s | FPS | RSS steady / peak MB | load avg |
|---|---|---:|---:|---:|---:|---:|---:|
| 8 | Horizon + 6 mods | 9.8 | 16.2 | 4.0 | 122 | 2,644 / 2,771 | 32 |
| 8 | NeoForge + 6 mods | 19.5 | 50.0 | 30.2 | 72 | 2,325 / 2,592 | 56 |
| 8 | Horizon | 5.0 | 11.0 | 4.0 | 124 | 1,559 / 1,629 | 51 |
| 8 | NeoForge | 12.8 | 36.1 | 21.9 | 104 | 2,334 / 2,558 | 30 |
| 16 | Horizon + 6 mods | 10.8 | 27.0 | 11.3 | 90 | 2,925 / 3,032 | 40 |
| 16 | NeoForge + 6 mods | 26.4 | 82.5 | 64.3 | 25 | 3,016 / 3,519 | 45 |
| 16 | Horizon | 3.5 | 10.0 | 7.4 | 119 | 1,732 / 1,871 | 56 |
| 16 | NeoForge | 16.9 | 73.7 | 43.2 | 36 | 2,748 / 3,425 | 48 |

Same content, Horizon against NeoForge: the world is ready 3.1x sooner at 8 chunks and 3.1x at
16, the title screen 2.0x and 2.4x sooner, and the flights run 1.7x and 3.6x the frames. RAM is
not lower: Horizon's steady RSS grows 1.1 GB with the mods (61,816 block states against
vanilla's 35,723; the per-state tables are the next thing to measure), while the JVM stays
inside its 2 GB heap. Caveats, so none of this is a "10x" claim yet: other sessions and CI
runners kept the machine's load average between 30 and 56 on 14 threads, so the confidence
intervals are as wide as the means (`perf_bench.py --table`); Horizon's frames are paced near
the display's 144 Hz at 8 chunks; Horizon's title time includes building the content overlay
(about 5 s for six mods; it was rebuilt on every start then, and is kept for later starts now);
and the pack runs 1.21.1 against Horizon's 26.3.
A quiet rerun with more games is the next measurement.

**Where the RAM goes (2026-10-17).** RSS overstates it on macOS. `ps` counts pages the allocator
freed and marked reusable, and the content tables free a lot at load. `perf_bench.py` now also
samples the physical footprint (`footprint`, what the OS charges the process). The machine was
shared and very busy (load average 90-138 on 14 threads). RD 8, the same six mods, one or two
games per row:

| game | RSS steady MB | footprint steady MB |
|---|---:|---:|
| Horizon | 1,598-1,636 | 1,277-1,295 |
| Horizon + 6 mods | 2,996-3,052 | 1,736-1,869 |

So the six mods cost about 0.5 GB of footprint, not 1.1-1.4 GB. ATM10's 42 mods (193,762
states) take the game to 7.7 GB RSS but 3.9 GB footprint. The rest is startup garbage the
allocator keeps.

`crates/horizon-client/examples/resource_memory.rs` breaks it down per loader: the live heap
(a counting allocator), each step's peak, RSS and the footprint. Live heap after every loader,
vanilla against ATM10's 42 mods:

| loader | vanilla MB | ATM10 42 mods MB |
|---|---:|---:|
| block registry | 24 | 125 |
| assets (registry, models, sprites: 153 MB of pixels for 9,790 layers) | 94 | 657 |
| block facts and behaviours | +29 | +75 |
| items, recipes | +14 | +82 |
| light, mesh, collision, motion | +24 | +53 |
| worldgen | +79 | +182 |
| **live** / **footprint** | **240 / 551** | **1,049 / 2,724** |

The block registry kept a second copy of every state as the key of its id map; it now
indexes ids by a hash checked against the states: -22 MB live for vanilla, -124 MB for
ATM10's, -30 MB and -140 MB of footprint. The startup peaks are what is left. Each step parses
its per-state tables whole: as JSON trees, or as NBT trees of 300-600 MB each for ATM10
(`block-properties.nbt`, the collision, support, occlusion and movement tables). The peak
reaches 3.9 GB during worldgen loading, and the footprint stays near the peak.

The NBT tables now stream: the readers check each state's identity as it is read, and no
`states` tree is built (#753). That tree was about 240 MB for each table. With the carried
ATM10 mods (153,511 states), the peak of each step falls by about 210 MB:

| step | before MB | after MB |
|---|---:|---:|
| light | 911 | 699 |
| collision | 945 | 733 |
| motion | 1,427 | 1,215 |
| worldgen, uncached | 3,000 | 2,788 |

The fluid tables no longer decode the 211 MB `gameplay-facts.json` a second time (#754). The
content root is kept between starts (#756). What is left at startup:

- `facts.json` went through a JSON tree, then an NBT tree, in both the registry and the assets
  step. It now streams (#825): at ATM10's size (214,338 states) each step's peak fell from
  816 MB to 153 MB (registry) and 235 MB (assets), and the RSS after the assets step from
  1,344 MB to 442 MB;
- on a first start, the content-root build and `Behaviours`' decode of `gameplay-facts.json`
  (cached afterwards in the behaviour snapshot).

**Against NeoForge, same 40 mods (2026-10-17).** The 40 data-tier mods carried from ATM10 (the
42 without Regions Unexplored and MO Structures, whose libraries are only on CurseForge),
against their jars on NeoForge 21.1.259 with `-Xmx2G`. `perf_bench.py --port-work`, RD 8, one
game each, load average 80-125 on 14 threads; `--warm` measures a later start:

| game | title / world s | RSS steady / peak MB | footprint steady / peak MB |
|---|---|---|---|
| Horizon before #756 (every start) | 81.1 / 102.8 | 4,008 / 4,164 | 2,368 / 2,554 |
| Horizon, first start | 105.2 / 128.8 | 3,795 / 3,993 | 2,306 / 2,560 |
| **Horizon, later starts** | **21.6 / 33.7** | **2,629 / 2,935** | **2,445 / 2,731** |
| NeoForge + 40 mods | 53.2 / 119.9 | 3,099 / 3,203 | 3,304 / 3,381 |

On later starts, Horizon uses 15 % less RSS and 26 % less footprint than NeoForge with the
same mods. It reaches the title 2.5x sooner and the world 3.6x sooner, and its flights ran at
93-233 FPS against NeoForge's 27-62. The first start is slower than NeoForge's to the title,
because it builds the content root once. One game per row on a loaded machine is not a
benchmark; a quiet rerun with repeats is still to do.

## Measured end to end

### Three packs through the mod browser, measured

2026-10-22, Mac mini M4 Pro (offscreen, a debug launcher, release-profile `horizon-port-pack` and game), while
other sessions kept the CPU at 85 to 93 %, so times are upper bounds. The two Modrinth packs were imported with
`horizon-launcher mods install <slug>` (the browser's Import), ATM10 from its CurseForge zip with `modpack import`
(CurseForge support is coming soon), then each ported with `--resources` for 26.3 and opened as a survival
world with every ported mod on (horizon-ctl `launch --dev-mod ...`, from a scratch script).

| Pack | Files | Import | Port | Ported mods | Coverage | Declared | World load (resources) | Crashes |
|---|---|---|---|---|---|---|---|---|
| Vanilla Perfected 26.3 (Fabric, small) | 108 | 30.4 s | 1.0 s | 2 | 2 partial, 79 not yet, 27 not needed | 0 blocks (a trail effect, a torch-flower texture) | 5.2 s (2.1 s) | none |
| Slimes Adventure 1.13.4 (Fabric 1.21.1, medium) | 105 | 18.8 s | 22.8 s | 20 | 20 partial, 46 not yet, 39 not needed | 8,208 blocks, 41 items, 1,376 recipes | 23.0 s (15.0 s) | none |
| All the Mods 10 8.3 (NeoForge 1.21.1, CurseForge zip) | 496 | 3.1 s | 29.4 s | 42 | 42 partial, 333 not yet, 121 not needed | 10,000 blocks, 1,273 items, 4,178 recipes | 38.3 s (28.7 s) | none |

The same world with no mods loads in 5.4 s (resources 1.1 s). Import is the pack download and Modrinth's answers by
file hash; Vanilla Perfected's 30 s is mostly its 108 lookups and its download. Port is the jars (downloaded for the
two Modrinth packs; ATM10's 42 copied from a folder, 12 more are on CurseForge only: CurseForge downloads coming soon) and the carry,
which writes tens of thousands of small files. World load grows with the blocks the pack declares: ATM10 adds
about 155,000 block states, and loading their models and textures is most of its 28.7 s.

Every world loaded and stayed up, with no panic and no error in the log. Before the namespace fix above, Slimes
Adventure lost three of YUNG's mods at start ("both use the namespace yungsapi"); after it all 20 load. As a share of
the mods that need porting (not counting performance mods and libraries), 2 of 81 ported partly, 20 of 66 and 42 of
375. Every ported mod is Partial: their Java code (block entities, entities, Mixins) doesn't come along.

## Open questions for Ludovic

- Contacting authors of permissively licensed mods to publish ports (none contacted).
- Whether players should run code-port agents themselves (their own Claude Code or Codex
  login, as Zenith does) or only download published ports.
- CurseForge: dropped for now (its API needs a paid key; Ludovic, 2026-10-22), shown as coming
  soon. CurseForge packs import from their zip or an installed instance.
