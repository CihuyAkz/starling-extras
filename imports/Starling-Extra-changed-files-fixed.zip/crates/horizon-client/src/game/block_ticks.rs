//! The block phases of a level's tick (`ServerLevel.tick`): scheduled ticks, random ticks in the
//! chunks the tickets simulate, block events and moving pistons (`tick_blocks`).
use super::*;

impl Game<'_> {
    /// ServerLevel.tick block phases: scheduled ticks, random ticks in the
    /// chunks the tickets simulate, block events and moving pistons.
    /// The length the block log had after the changed blocks went out
    /// (`ServerChunkCache.tick`'s broadcast), before the block events and the
    /// block entities ran.
    pub(super) fn tick_blocks(&mut self) -> Result<Option<usize>> {
        let mut scratch = std::mem::take(&mut self.tick_scratch);
        let result = self.tick_blocks_with_scratch(&mut scratch);
        self.tick_scratch = scratch;
        result
    }
    pub(super) fn tick_blocks_with_scratch(
        &mut self,
        scratch: &mut TickScratch,
    ) -> Result<Option<usize>> {
        let mut laps = horizon_client::spans::laps();
        // ServerChunkCache.tick: the tickets that time out.
        let world = &self.world;
        self.tickets
            .tick_portal(|ticket| portal_ticket_can_expire(world, ticket));
        self.sync_tick_chunks();
        self.start_ticking_chunks();
        laps.lap("tb_tickets");
        self.random_tick_chunks(&mut scratch.ticking);
        laps.lap("tb_chunks");
        // Entity.checkInsideBlocks for the plates, tripwires, detector rails and
        // buttons under the players (the host and the LAN guests), the minecarts
        // and the arrows (the mobs and other entities are added in `with_level`
        // below).
        scratch.inside.clear();
        let guests = self.lan_block_trigger_boxes().into_iter().map(|(_, b)| b);
        let boxes = self
            .player
            .iter()
            .filter(|_| !self.spectator())
            .map(|p| {
                let w = f64::from(p.dimensions.width) / 2.0;
                let h = f64::from(p.dimensions.height);
                (
                    [p.position.x - w, p.position.y, p.position.z - w],
                    [p.position.x + w, p.position.y + h, p.position.z + w],
                )
            })
            .chain(self.carts.iter().map(|c| {
                let p = c.position;
                (
                    [p.x - 0.49, p.y, p.z - 0.49],
                    [p.x + 0.49, p.y + 0.7, p.z + 0.49],
                )
            }))
            .chain(guests);
        for (lo, hi) in boxes {
            for x in (lo[0] + 1e-7).floor() as i32..=(hi[0] - 1e-7).floor() as i32 {
                for y in (lo[1] + 1e-7).floor() as i32..=(hi[1] - 1e-7).floor() as i32 {
                    for z in (lo[2] + 1e-7).floor() as i32..=(hi[2] - 1e-7).floor() as i32 {
                        scratch.inside.push(BlockPos::new(x, y, z));
                    }
                }
            }
        }
        // AbstractArrow.applyEffectsFromBlocks: the blocks every arrow passed
        // through this tick (a wooden button is pressed by one inside it), and
        // the ones a thrown trident is in.
        for p in self
            .creatures
            .projectiles
            .iter()
            .filter(|p| p.arrow.is_some())
        {
            scratch.inside.extend(horizon_client::arrows::blocks_inside(
                p.previous, p.position,
            ));
        }
        for t in &self.tridents {
            scratch.inside.extend(horizon_client::arrows::blocks_inside(
                t.position, t.position,
            ));
        }
        // BigDripleafBlock.entityInside also asks whether the player stands on
        // the ground and how high its feet are: the leaves its box's feet
        // layer is inside (the host and the LAN guests).
        scratch.standing.clear();
        let feet = self
            .player
            .iter()
            .filter(|_| !self.spectator())
            .map(|p| {
                (
                    [p.position.x, p.position.y, p.position.z],
                    p.ground.on_ground,
                    f64::from(p.dimensions.width) / 2.0,
                )
            })
            .chain(
                self.lan_guest_feet()
                    .into_iter()
                    .map(|(at, on_ground)| (at, on_ground, 0.3)),
            );
        for (at, on_ground, w) in feet {
            let y = (at[1] + 1e-7).floor() as i32;
            for x in (at[0] - w + 1e-7).floor() as i32..=(at[0] + w - 1e-7).floor() as i32 {
                for z in (at[2] - w + 1e-7).floor() as i32..=(at[2] + w - 1e-7).floor() as i32 {
                    scratch
                        .standing
                        .push((BlockPos::new(x, y, z), on_ground, at[1]));
                }
            }
        }
        // ServerLevel.tick ticks only the entities in entity-ticking chunks, and
        // applyEffectsFromBlocks runs in their tick: a mob or item past the
        // simulation distance presses, burns and slows on nothing.
        let entity_ticking = self.entity_ticking_area();
        let first_contact_drop = self.next_entity + 1;
        self.with_level(|b, level, ticks| {
            // LilyPadBlock.entityInside: a boat inside a lily pad breaks it.
            scratch.boat_cells.clear();
            for bounds in level.boat_trigger_boxes() {
                let (lo, hi) = (bounds.min_position(), bounds.max_position());
                for x in (lo.x + 1e-7).floor() as i32..=(hi.x - 1e-7).floor() as i32 {
                    for y in (lo.y + 1e-7).floor() as i32..=(hi.y - 1e-7).floor() as i32 {
                        for z in (lo.z + 1e-7).floor() as i32..=(hi.z - 1e-7).floor() as i32 {
                            scratch.boat_cells.push(BlockPos::new(x, y, z));
                        }
                    }
                }
            }
            for pos in scratch.boat_cells.drain(..) {
                b.boat_inside(level, ticks, pos);
            }
            // The mobs and the other entities (items, orbs, projectiles...) too.
            scratch.touched.clear();
            use entity::{Entity as _, for_each_entity};
            let mut touch = |bounds: Aabb| {
                let (lo, hi) = (bounds.min_position(), bounds.max_position());
                for x in (lo.x + 1e-7).floor() as i32..=(hi.x - 1e-7).floor() as i32 {
                    for y in (lo.y + 1e-7).floor() as i32..=(hi.y - 1e-7).floor() as i32 {
                        for z in (lo.z + 1e-7).floor() as i32..=(hi.z - 1e-7).floor() as i32 {
                            scratch.touched.push(BlockPos::new(x, y, z));
                        }
                    }
                }
            };
            for_each_entity!(level.entities, entity => {
                if entity.triggers_blocks() && entity.sweeps_blocks_inside() {
                    let at = entity.position();
                    if entity_ticking(at.x.floor() as i32, at.z.floor() as i32) {
                        touch(entity.bounds());
                    }
                }
            });
            for crystal in level.crystals {
                touch(crystal.bounds());
            }
            for &(bounds, applies) in &level.trigger_hooks {
                if applies {
                    touch(bounds);
                }
            }
            for &bounds in &level.trigger_extras {
                touch(bounds);
            }
            for pos in scratch.inside.drain(..) {
                b.entity_inside(level, ticks, pos);
            }
            // The touched blocks go once each, in (x, y, z) order. Only an
            // entity-sensing block does anything there, so the others are
            // passed over while no block has changed since they were looked
            // at (they are still not sensing), and only the few sensing ones
            // are sorted. Once a block changes, every later one goes, as the
            // whole sorted list would.
            let key = |p: &BlockPos| (p.x, p.y, p.z);
            scratch.sensing.clear();
            scratch.rest.clear();
            for pos in scratch.touched.drain(..) {
                if b.senses_entities(level.world.block(pos.x, pos.y, pos.z)) {
                    scratch.sensing.push(pos);
                } else {
                    scratch.rest.push(pos);
                }
            }
            scratch.sensing.sort_unstable_by_key(key);
            scratch.sensing.dedup();
            let looked = (
                level.world.revision,
                level.world.chunks.membership_revision(),
            );
            let mut i = 0;
            while i < scratch.sensing.len() {
                let pos = scratch.sensing[i];
                b.entity_inside(level, ticks, pos);
                i += 1;
                let now = (
                    level.world.revision,
                    level.world.chunks.membership_revision(),
                );
                if now != looked {
                    scratch.later.clear();
                    scratch.later.append(&mut scratch.rest);
                    scratch.later.extend(scratch.sensing.drain(i..));
                    scratch.later.retain(|p| key(p) > key(&pos));
                    scratch.later.sort_unstable_by_key(key);
                    scratch.later.dedup();
                    for pos in scratch.later.drain(..) {
                        b.entity_inside(level, ticks, pos);
                    }
                    break;
                }
            }
            for (pos, on_ground, feet_y) in scratch.standing.drain(..) {
                b.entity_on_big_dripleaf(level, ticks, pos, on_ground, feet_y);
            }
        });
        self.process_level_events()?;
        self.contact_drops = first_contact_drop..self.next_entity + 1;
        laps.lap("tb_entity_inside");
        // ServerLevel.tick: a Debug world runs no scheduled block or fluid ticks, and
        // ServerChunkCache.tickChunks no random ticks.
        let debug = self.world_debug;
        if !debug {
            self.tick_scheduled()?;
        }
        horizon_threads::work::clear_work();
        self.with_level(|b, level, ticks| {
            // The masks the random ticks will read, built on helper threads first while the
            // parallel tick is on (`HORIZON_PARALLEL_TICK`): the draws and ticks don't depend on them.
            if !debug && horizon_client::parallel::lanes() > 1 {
                horizon_client::spans::time("random_tick_masks", || {
                    let chunks = &level.world.chunks;
                    level.random_tick_sections.prepare_masks(
                        &scratch.ticking,
                        |key| chunks.get(&key).cloned(),
                        level.facts,
                        &|id| b.random_tick_candidate(BlockStateId(id)),
                    );
                });
            }
            horizon_client::spans::time("random_ticks", || {
                for (x, z) in scratch.ticking.drain(..).filter(|_| !debug) {
                    // The last answer, asked from Y `from` at a world revision:
                    // the next ticking section and its mask. It stands for a
                    // later Y up to that section's until a block changes.
                    let mut last: Option<(u64, i32, Option<(i32, std::rc::Rc<_>)>)> = None;
                    let pos = horizon_core::position::ChunkPos::new(x, z);
                    b.tick_chunk_random_masked(level, ticks, pos, |level, from| {
                        let revision = level.world.revision;
                        let stands = last.as_ref().is_some_and(|(r, f, next)| {
                            *r == revision
                                && *f <= from
                                && next.as_ref().is_none_or(|(y, _)| from <= *y)
                        });
                        if !stands {
                            let next = level.world.chunks.get(&(x, z)).and_then(|chunk| {
                                level.random_tick_sections.next_masked(
                                    (x, z),
                                    chunk,
                                    level.facts,
                                    |id| b.random_tick_candidate(BlockStateId(id)),
                                    from,
                                )
                            });
                            last = Some((revision, from, next));
                        }
                        last.as_ref()
                            .and_then(|(_, _, next)| next.as_ref())
                            .map(|(y, mask)| (*y, Some(mask.clone())))
                    });
                }
            });
        });
        horizon_threads::work::clear_work();
        laps = horizon_client::spans::laps();
        let sent = self.lan_broadcast_changes();
        laps.lap("tb_broadcast");
        self.save_chunks_eagerly();
        self.with_level(|b, level, ticks| {
            b.run_block_events(level, ticks);
        });
        laps.lap("tb_block_events");
        self.process_level_events()?;
        laps.lap("tb_level_events");
        self.sync_moving_pistons();
        laps.lap("tb_pistons");
        Ok(sent)
    }

    /// `ChunkMap.forEachBlockTickingChunk`: the chunks that random tick this
    /// tick, empty ones included (`tickChunk` still draws for precipitation in
    /// those).
    ///
    /// Vanilla walks the simulation tracker's own table, whose order doesn't
    /// follow chunk loading. The world map's order does: it is filled as the
    /// streaming workers finish, so the level random's draws landed on other
    /// blocks from one run of a world to the next (#15164). Chunk position
    /// order is the same every run; vanilla's exact order is its fastutil
    /// table's slot order, which follows that table's whole history.
    pub(super) fn random_tick_chunks(&self, out: &mut Vec<(i32, i32)>) {
        let levels = self.tickets.levels();
        let bounds = levels.random_tick_bounds();
        out.clear();
        out.extend(self.world.chunks.keys().copied().filter(|&(x, z)| {
            if let Some((min_x, min_z, max_x, max_z)) = bounds
                && (x < min_x || x > max_x || z < min_z || z > max_z)
            {
                return false;
            }
            levels.random_ticking(x, z) && ticking_chunk(&self.world, x, z)
        }));
        out.sort_unstable();
    }
    /// Track which chunks are ticking (Ticks needs chunk load/unload).
    pub(super) fn sync_tick_chunks(&mut self) {
        if !self.tick_chunks.synchronize(&self.world.chunks) {
            return;
        }
        // Move only the added keys out so registration can borrow all of Game.
        let added = self.tick_chunks.take_added();
        for &key in &added {
            self.register_chunk_ticks(key);
        }
        for &key in self.tick_chunks.removed() {
            self.random_tick_sections.remove(&key);
            self.portals.sections.remove(&key);
            self.block_ticks
                .remove_chunk(horizon_core::position::ChunkPos::new(key.0, key.1));
            self.block_ticks
                .comparator_outputs
                .retain(|p, _| (p.x >> 4, p.z >> 4) != key);
            self.hoppers.retain(|p, _| (p.0 >> 4, p.2 >> 4) != key);
            // Its moving pistons were saved with it and load back with it.
            self.block_ticks
                .moving_pistons
                .retain(|(p, _)| (p.x >> 4, p.z >> 4) != key);
        }
        self.tick_chunks.recycle_added(added);
    }

    /// `ServerLevel.tick`: moving block entities push after entity travel.
    pub(super) fn tick_moving_pistons(&mut self) -> Result<()> {
        self.with_level(|b, level, ticks| b.tick_block_entities(level, ticks));
        let pushes = std::mem::take(&mut self.block_ticks.piston_pushes);
        self.push_piston_entities(pushes);
        self.process_level_events()?;
        self.sync_moving_pistons();
        Ok(())
    }

    /// `ServerLevel.tick`'s scheduled block then fluid ticks, one at a time:
    /// the side effects of each (a shrieker summoning a warden, drops, game
    /// events) happen before the next tick runs, as they do inline in vanilla.
    pub(super) fn tick_scheduled(&mut self) -> Result<()> {
        for fluids in [false, true] {
            let mut laps = horizon_client::spans::laps();
            let name = if fluids { "tb_fluids" } else { "tb_scheduled" };
            if !self.with_level(|b, level, ticks| b.scheduled_begin(level, ticks, fluids)) {
                laps.lap(name);
                continue;
            }
            loop {
                // Due ticks run against one level while each leaves nothing for
                // the game to apply (level events, spilled items or orbs): the
                // next one would see the same level built again.
                let more = self.with_level(|b, level, ticks| {
                    loop {
                        let more = b.scheduled_step(level, ticks, fluids);
                        if !more || !level.events.is_empty() || !level.spill.is_empty() {
                            break more;
                        }
                    }
                });
                if !self.level_events.is_empty() {
                    self.process_level_events()?;
                }
                if !more {
                    break;
                }
            }
            self.with_level(|b, _, ticks| b.scheduled_finish(ticks, fluids));
            laps.lap(name);
        }
        Ok(())
    }
}

#[cfg(test)]
mod random_order_tests;
