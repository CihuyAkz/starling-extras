pub(super) struct EffectTickChange;
