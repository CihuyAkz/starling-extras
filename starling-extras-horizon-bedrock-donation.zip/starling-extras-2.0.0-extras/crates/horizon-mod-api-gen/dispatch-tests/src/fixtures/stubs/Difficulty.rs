pub(super) struct Difficulty;
