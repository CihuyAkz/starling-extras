pub(super) struct LootStack;
