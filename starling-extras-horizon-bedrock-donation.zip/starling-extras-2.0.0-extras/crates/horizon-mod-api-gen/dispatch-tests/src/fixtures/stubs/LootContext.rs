pub(super) struct LootContext;
