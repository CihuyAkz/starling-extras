pub(super) struct ItemAttributeModifier;
