pub(super) struct TriState;
