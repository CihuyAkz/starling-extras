pub(super) struct NoteInstrument;
