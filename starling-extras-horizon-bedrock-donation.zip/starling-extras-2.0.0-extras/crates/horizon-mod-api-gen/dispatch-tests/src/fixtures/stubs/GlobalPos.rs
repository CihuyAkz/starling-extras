pub(super) struct GlobalPos;
