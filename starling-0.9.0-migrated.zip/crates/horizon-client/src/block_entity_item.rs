//! Block entities carried by items, vanilla 26.3: Ctrl + Pick Block in creative
//! (`ServerGamePacketListenerImpl.addBlockDataToItem`) and placing such an item
//! (`BlockItem.updateCustomBlockEntityTag`, then
//! `BlockEntity.applyComponentsFromItemStack`). Both work on the block entity's
//! saved NBT (`block_entity_nbt::canonical`) and the item's component patch.
//!
//! What a type turns into item components (`removeComponentsFromTag`,
//! `collectImplicitComponents`) leaves its NBT; the rest goes to
//! `minecraft:block_entity_data`, tagged with the type's id.
use crate::block_entity_nbt::{self, canonical};
use horizon_core::nbt::{Compound, JavaString, Tag};

pub const BLOCK_ENTITY_DATA: &str = "minecraft:block_entity_data";

/// `BlockEntityTypes.OP_ONLY_CUSTOM_DATA`: the types whose data only a player
/// who can use game master blocks places (`BlockEntityType.onlyOpCanSetNbt`).
pub const OP_ONLY: [&str; 6] = [
    "minecraft:command_block",
    "minecraft:lectern",
    "minecraft:sign",
    "minecraft:hanging_sign",
    "minecraft:mob_spawner",
    "minecraft:trial_spawner",
];

/// The `minecraft:block_entity_data` of `stack`: its type id and its data.
pub fn data(stack: &crate::items::ItemStack) -> Option<(String, &Tag)> {
    let data = stack.data()?.other(BLOCK_ENTITY_DATA)?;
    Some((block_entity_nbt::id(data)?, data))
}

/// `JukeboxBlock.setPlacedBy`: the item's `minecraft:block_entity_data`
/// carries a `RecordItem`, so the placed jukebox holds a record and its
/// `has_record` state has to say so. Vanilla reads the item's data, not the
/// block entity the placement just filled.
pub fn carries_record(stack: &crate::items::ItemStack) -> bool {
    stack
        .data()
        .and_then(|d| d.other(BLOCK_ENTITY_DATA))
        .is_some_and(|data| data.get("RecordItem").is_some())
}

/// `LecternBlock.getStateForPlacement`: the item's `minecraft:block_entity_data`
/// carries a `Book` (`TypedEntityData.contains` checks the key only), so the
/// placed lectern's `has_book` state says so. Vanilla reads the item's data,
/// not the block entity the placement just filled.
pub fn carries_book(stack: &crate::items::ItemStack) -> bool {
    stack
        .data()
        .and_then(|d| d.other(BLOCK_ENTITY_DATA))
        .is_some_and(|data| data.get("Book").is_some())
}

/// `BlockItem.shouldPrintOpWarning` for a player with game master permission:
/// the item carries data of an op-only type.
pub fn op_warning(stack: &crate::items::ItemStack) -> bool {
    data(stack).is_some_and(|(id, _)| OP_ONLY.contains(&id.as_str()))
}

/// `EntityTypes.OP_ONLY_CUSTOM_DATA`: the entity types whose data only a player
/// who can use game master blocks sets (`EntityType.onlyOpCanSetNbt`).
fn egg_op_only(id: &str) -> bool {
    matches!(
        id,
        "minecraft:falling_block"
            | "minecraft:command_block_minecart"
            | "minecraft:spawner_minecart"
    )
}

/// `SpawnEggItem.shouldPrintOpWarning` for a player with game master
/// permission: a spawn egg carries data of an op-only entity type.
pub fn spawn_egg_op_warning(stack: &crate::items::ItemStack) -> bool {
    stack.item.ends_with("_spawn_egg")
        && matches!(
            stack
                .data()
                .and_then(|d| d.other("minecraft:entity_data"))
                .and_then(|data| data.get("id")),
            Some(Tag::String(id)) if egg_op_only(&id.to_string_lossy())
        )
}

/// `SpawnEggItem.useOn` on a spawner: the type it sets (`getType`: the egg's
/// entity data id, else the egg's own type) and, for an op
/// (`PlayerList.isOp`), that entity data for `Spawner.setEntityData`; anyone
/// else sets only the type (`setEntityId`).
pub fn spawn_egg_on_spawner(
    stack: &crate::items::ItemStack,
    op: bool,
) -> (String, Option<Compound>) {
    let data = match stack.data().and_then(|d| d.other("minecraft:entity_data")) {
        Some(Tag::Compound(c)) => Some(c),
        _ => None,
    };
    let id = match data.and_then(|c| c.get(&JavaString::from("id"))) {
        Some(Tag::String(id)) => id.to_string_lossy(),
        _ => {
            let kind = stack.item.trim_end_matches("_spawn_egg");
            format!("minecraft:{}", kind.trim_start_matches("minecraft:"))
        }
    };
    (id, data.filter(|_| op).cloned())
}

/// `EntityType.updateCustomEntityTag`: the `minecraft:entity_data` a spawn egg
/// puts on the mob it spawned — only when the data names the spawned type (data
/// without an `id` is the egg's own), and an op-only type's data only for an op.
pub fn spawn_egg_entity_data<'a>(
    stack: &'a crate::items::ItemStack,
    spawned: &str,
    op: bool,
) -> Option<&'a Tag> {
    let data = stack.data()?.other("minecraft:entity_data")?;
    if matches!(data.get("id"), Some(Tag::String(id)) if id.to_string_lossy() != spawned) {
        return None;
    }
    if egg_op_only(spawned) && !op {
        return None;
    }
    Some(data)
}

/// `EntityType.appendDefaultStackConfig` for a hanging entity or armor stand an
/// item places: `Entity.applyImplicitComponents` stores the item's
/// `minecraft:custom_name` as the entity's `CustomName` and its
/// `minecraft:custom_data` as its `data`, then `updateCustomEntityTag`
/// (`TypedEntityData.loadInto`) merges the item's `minecraft:entity_data` over
/// the entity's saved tag `own` when its type is `kind`.
pub fn stack_configured_entity(stack: &crate::items::ItemStack, kind: &str, own: &Tag) -> Tag {
    stack_configured_entity_by(stack, kind, own, false)
}

/// [`stack_configured_entity`], `op` saying whether the user may load the
/// data of an op-only entity type (`EntityType.onlyOpCanSetNbt`).
pub fn stack_configured_entity_by(
    stack: &crate::items::ItemStack,
    kind: &str,
    own: &Tag,
    op: bool,
) -> Tag {
    let mut tag = own.clone();
    if let Tag::Compound(map) = &mut tag {
        if let Some(name) = stack.data().and_then(|d| d.custom_name.clone()) {
            map.insert("CustomName".into(), name);
        }
        if let Some(custom) = stack.data().and_then(|d| d.other("minecraft:custom_data")) {
            map.insert("data".into(), custom.clone());
        }
    }
    match spawn_egg_entity_data(stack, kind, op) {
        Some(data) => crate::data_cmd::merged(&tag, data),
        None => tag,
    }
}

/// `Spawner.getSpawnEntityDisplayName` (`SpawnData.entity.id` of the item's
/// data, which `ItemStack.addDetailsToTooltip` reads for spawners and trial
/// spawners alike): the entity type a spawner item spawns.
pub fn spawner_entity(stack: &crate::items::ItemStack) -> Option<String> {
    let (_, data) = data(stack)?;
    match data.get("SpawnData")?.get("entity")?.get("id")? {
        Tag::String(id) => Some(id.to_string_lossy()),
        _ => None,
    }
}

/// A part of a block entity's NBT that its item holds as a component.
#[derive(Clone, Copy)]
enum Part {
    /// The NBT key and the component hold the same value.
    Same(&'static str, &'static str),
    /// `Items` as `minecraft:container`, in a container of this many slots.
    Items(usize),
    /// `LootTable` and `LootTableSeed` as `minecraft:container_loot`.
    Loot,
    /// `is_waxed` as `minecraft:waxed`.
    Waxed,
    /// A decorated pot's `item` as `minecraft:container`.
    PotItem,
    /// Left out of the item's data, with no component.
    Drop(&'static str),
}
const NAME: Part = Part::Same("CustomName", "minecraft:custom_name");
const LOCK: Part = Part::Same("lock", "minecraft:lock");
const CONTAINER: &str = "minecraft:container";

/// Each type's `removeComponentsFromTag`, `collectImplicitComponents` and
/// `applyImplicitComponents`.
fn parts(id: &str) -> &'static [Part] {
    match id {
        "minecraft:chest"
        | "minecraft:trapped_chest"
        | "minecraft:barrel"
        | "minecraft:shulker_box" => &[NAME, LOCK, Part::Items(27), Part::Loot],
        "minecraft:dispenser" | "minecraft:dropper" | "minecraft:crafter" => {
            &[NAME, LOCK, Part::Items(9), Part::Loot]
        }
        "minecraft:hopper" => &[NAME, LOCK, Part::Items(5), Part::Loot],
        "minecraft:furnace" | "minecraft:smoker" | "minecraft:blast_furnace" => {
            &[NAME, LOCK, Part::Items(3)]
        }
        "minecraft:brewing_stand" => &[NAME, LOCK, Part::Items(5)],
        "minecraft:beacon" => &[NAME, LOCK],
        "minecraft:enchanting_table" => &[NAME],
        "minecraft:command_block" => &[NAME, Part::Drop("conditionMet"), Part::Drop("powered")],
        "minecraft:campfire" => &[Part::Items(4)],
        "minecraft:chiseled_bookshelf" => &[Part::Items(6)],
        "minecraft:shelf" => &[Part::Items(3)],
        "minecraft:beehive" => &[Part::Same("bees", "minecraft:bees")],
        "minecraft:banner" => &[Part::Same("patterns", "minecraft:banner_patterns"), NAME],
        "minecraft:decorated_pot" => &[
            Part::Same("sherds", "minecraft:pot_decorations"),
            Part::PotItem,
        ],
        "minecraft:sign" | "minecraft:hanging_sign" => &[
            Part::Same("front_text", "minecraft:sign_text_front"),
            Part::Same("back_text", "minecraft:sign_text_back"),
            Part::Waxed,
        ],
        "minecraft:skull" => &[
            Part::Same("profile", "minecraft:profile"),
            Part::Same("note_block_sound", "minecraft:note_block_sound"),
            Part::Same("custom_name", "minecraft:custom_name"),
        ],
        _ => &[],
    }
}

/// The component a part reads, and what it holds for `tag` (None: unset).
fn collect(part: Part, tag: &Tag) -> Option<(&'static str, Option<Tag>)> {
    Some(match part {
        Part::Same(key, component) => (
            component,
            tag.get(key).cloned().or_else(|| unset(component)),
        ),
        Part::Items(_) => {
            let slots = match tag.get("Items") {
                Some(Tag::List(items)) => items.iter().filter_map(slot_entry).collect(),
                _ => Vec::new(),
            };
            (CONTAINER, Some(Tag::List(slots)))
        }
        Part::Loot => {
            let table = tag.get("LootTable").cloned();
            let loot = table.map(|t| {
                let mut entries = vec![("loot_table", t)];
                if let Some(seed) = tag.get("LootTableSeed") {
                    entries.push(("seed", seed.clone()));
                }
                Tag::compound(entries)
            });
            ("minecraft:container_loot", loot)
        }
        Part::Waxed => (
            "minecraft:waxed",
            crate::entity_nbt::flag(tag, "is_waxed").then(|| Tag::Compound(Compound::new())),
        ),
        Part::PotItem => {
            let slots = match tag.get("item") {
                Some(Tag::Compound(item)) => Some(container_slot(0, item.clone())),
                _ => None,
            };
            (CONTAINER, Some(Tag::List(slots.into_iter().collect())))
        }
        Part::Drop(_) => return None,
    })
}

/// What a type that always collects `component` gives when its NBT leaves the
/// value out (its empty value, which the NBT omits).
fn unset(component: &str) -> Option<Tag> {
    Some(match component {
        "minecraft:bees" | "minecraft:banner_patterns" => Tag::List(Vec::new()),
        "minecraft:pot_decorations" => Tag::Compound(Compound::new()),
        "minecraft:sign_text_front" | "minecraft:sign_text_back" => {
            block_entity_nbt::sign_side(None)
        }
        _ => return None,
    })
}

/// An `Items` entry as a `minecraft:container` slot.
fn slot_entry(entry: &Tag) -> Option<Tag> {
    let Tag::Compound(entry) = entry else {
        return None;
    };
    let mut item = entry.clone();
    let slot = match item.remove(&JavaString::from("Slot"))? {
        Tag::Byte(s) => i32::from(s),
        _ => return None,
    };
    Some(container_slot(slot, item))
}

/// An `ItemContainerContents` slot: `ItemStackTemplate` leaves out a count of 1.
fn container_slot(slot: i32, mut item: Compound) -> Tag {
    if item.get(&JavaString::from("count")) == Some(&Tag::Int(1)) {
        item.remove(&JavaString::from("count"));
    }
    Tag::compound([("slot", Tag::Int(slot)), ("item", Tag::Compound(item))])
}

/// The value of `component` on the clone item of a type that collects it: a
/// picked item leaves it out of its patch, and a placed item without it in its
/// patch gives it to the block entity.
fn item_default(component: &str) -> Option<Tag> {
    Some(match component {
        CONTAINER | "minecraft:bees" | "minecraft:banner_patterns" => Tag::List(Vec::new()),
        "minecraft:pot_decorations" => {
            let brick = || Tag::compound([("id", Tag::String("minecraft:brick".into()))]);
            Tag::compound([
                ("back", brick()),
                ("front", brick()),
                ("left", brick()),
                ("right", brick()),
            ])
        }
        "minecraft:sign_text_front" | "minecraft:sign_text_back" => {
            block_entity_nbt::sign_side(None)
        }
        _ => return None,
    })
}

const SIGN_TEXT: [&str; 2] = ["minecraft:sign_text_front", "minecraft:sign_text_back"];

const METADATA: [&str; 6] = ["id", "x", "y", "z", "keepPacked", "components"];

/// `saveCustomOnly`: the saved NBT without its id, position and components.
fn custom_only(saved: &Tag) -> Compound {
    match saved {
        Tag::Compound(c) => c
            .iter()
            .filter(|(k, _)| !METADATA.contains(&k.to_string_lossy().as_str()))
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect(),
        _ => Compound::new(),
    }
}

/// `BlockEntity.collectComponents`: explicit components plus the type's implicit components.
/// Unlike Ctrl + Pick Block, this does not carry the remaining block entity NBT.
pub fn collected_components(saved: &Tag) -> Compound {
    let id = block_entity_nbt::id(saved).unwrap_or_default();
    let mut collected = match saved.get("components") {
        Some(Tag::Compound(c)) => c.clone(),
        _ => Compound::new(),
    };
    for part in parts(&id) {
        if let Some((component, value)) = collect(*part, saved) {
            match value {
                Some(v) => collected.insert(component.into(), v),
                None => collected.remove(&JavaString::from(component)),
            };
        }
    }
    collected
}

/// `addBlockDataToItem`: the component patch Ctrl + Pick Block gives the clone
/// item of the block entity saved as `saved` (a full, canonical compound).
pub fn pick(saved: &Tag) -> Compound {
    let id = block_entity_nbt::id(saved).unwrap_or_default();
    let mut patch = Compound::new();
    // BlockItem.setBlockEntityData after removeComponentsFromTag.
    let mut data = custom_only(saved);
    for part in parts(&id) {
        let key = match *part {
            Part::Same(key, _) | Part::Drop(key) => key,
            Part::Items(_) => "Items",
            Part::Loot => {
                data.remove(&JavaString::from("LootTableSeed"));
                "LootTable"
            }
            Part::Waxed => "is_waxed",
            Part::PotItem => "item",
        };
        data.remove(&JavaString::from(key));
    }
    if !data.is_empty() {
        data.insert("id".into(), Tag::String(id.as_str().into()));
        patch.insert(BLOCK_ENTITY_DATA.into(), Tag::Compound(data));
    }
    // ItemStack.applyComponents(collectComponents()): the block entity's own
    // components, then the implicit ones; a value equal to the item's own is
    // no change.
    for (component, value) in collected_components(saved) {
        if item_default(&component.to_string_lossy()).as_ref() == Some(&value) {
            patch.remove(&component);
        } else {
            patch.insert(component, value);
        }
    }
    patch
}

/// The block entity saved as `saved` after an item with component patch
/// `components` is placed as it: `BlockItem.updateCustomBlockEntityTag` (the
/// item's data of the same type, op-only types only when `game_master`, the
/// player can use game master blocks), then `applyComponentsFromItemStack`.
pub fn place(saved: &Tag, components: &Compound, game_master: bool) -> Tag {
    let Some(id) = block_entity_nbt::id(saved) else {
        return saved.clone();
    };
    let Tag::Compound(mut tag) = saved.clone() else {
        return saved.clone();
    };
    // TypedEntityData.loadInto: saveCustomOnly, merge, loadCustomOnly when changed.
    if let Some(Tag::Compound(data)) = components.get(&JavaString::from(BLOCK_ENTITY_DATA))
        && data
            .get(&JavaString::from("id"))
            .is_some_and(|t| matches!(t, Tag::String(s) if s.to_string_lossy() == id))
        && (game_master || !OP_ONLY.contains(&id.as_str()))
    {
        let custom = custom_only(saved);
        let mut merged = custom.clone();
        let mut data = data.clone();
        data.remove(&JavaString::from("id"));
        crate::data_cmd::merge_compound(&mut merged, &data);
        if merged != custom {
            for key in METADATA {
                if let Some(v) = tag.get(&JavaString::from(key)) {
                    merged.insert(key.into(), v.clone());
                }
            }
            let merged = Tag::Compound(merged);
            // A native mod's live entity supplies its own canonical id and
            // schema. Keep the merged opaque payload for that type, while
            // retaining vanilla's load/save validation for minecraft types.
            let loaded =
                canonical(&merged).or_else(|| (!id.starts_with("minecraft:")).then_some(merged));
            if let Some(Tag::Compound(loaded)) = loaded {
                tag = loaded;
            }
        }
    }
    // applyImplicitComponents, then the rest of the patch as the block
    // entity's own components.
    let mut read = vec![BLOCK_ENTITY_DATA, "minecraft:block_state"];
    // The item's components: its patch over its own defaults.
    let get = |c: &str| match components.get(&JavaString::from(c)) {
        Some(v) => Some(v.clone()),
        None if components.contains_key(&JavaString::from(format!("!{c}").as_str())) => None,
        None => item_default(c),
    };
    let mut set = |key: &str, value: Option<Tag>| match value {
        Some(v) => tag.insert(key.into(), v),
        None => tag.remove(&JavaString::from(key)),
    };
    for part in parts(&id) {
        match *part {
            Part::Same(key, component) => {
                read.push(component);
                // A sign item that carries no text leaves the block's own: a content
                // sign's declared colour and glow (`createDefaultSignText`).
                let keeps_text = SIGN_TEXT.contains(&component)
                    && !components.contains_key(&JavaString::from(component))
                    && !components
                        .contains_key(&JavaString::from(format!("!{component}").as_str()));
                if !keeps_text {
                    set(key, get(component));
                }
            }
            Part::Items(size) => {
                read.push(CONTAINER);
                let items = container_slots(get(CONTAINER).as_ref())
                    .filter(|(slot, _)| (*slot as usize) < size)
                    .map(|(slot, mut item)| {
                        item.insert("Slot".into(), Tag::Byte(slot as i8));
                        Tag::Compound(item)
                    })
                    .collect();
                set("Items", Some(Tag::List(items)));
            }
            Part::Loot => {
                read.push("minecraft:container_loot");
                if let Some(loot) = get("minecraft:container_loot") {
                    set("LootTable", loot.get("loot_table").cloned());
                    set("LootTableSeed", loot.get("seed").cloned());
                }
            }
            Part::Waxed => {
                read.push("minecraft:waxed");
                set(
                    "is_waxed",
                    Some(Tag::Byte(i8::from(get("minecraft:waxed").is_some()))),
                );
            }
            Part::PotItem => {
                read.push(CONTAINER);
                let first = container_slots(get(CONTAINER).as_ref()).find(|(slot, _)| *slot == 0);
                set("item", first.map(|(_, item)| Tag::Compound(item)));
            }
            Part::Drop(_) => {}
        }
    }
    let own: Compound = components
        .iter()
        .filter(|(k, _)| {
            let k = k.to_string_lossy();
            !k.starts_with('!') && !read.contains(&k.as_str())
        })
        .map(|(k, v)| (k.clone(), v.clone()))
        .collect();
    tag.insert("components".into(), Tag::Compound(own));
    let tag = Tag::Compound(tag);
    canonical(&tag).unwrap_or(tag)
}

/// The slots of a `minecraft:container` component.
fn container_slots(container: Option<&Tag>) -> impl Iterator<Item = (i32, Compound)> + '_ {
    let list = match container {
        Some(Tag::List(list)) => list.as_slice(),
        _ => &[],
    };
    list.iter().filter_map(|entry| {
        let slot = match entry.get("slot")? {
            Tag::Int(s) => *s,
            _ => return None,
        };
        match entry.get("item")? {
            Tag::Compound(item) => Some((slot, item.clone())),
            _ => None,
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn snbt(text: &str) -> Tag {
        horizon_core::nbt::parse_snbt(text).expect("snbt").0
    }
    fn saved(text: &str) -> Tag {
        canonical(&snbt(text)).expect("known type")
    }
    fn canon(patch: &Compound) -> String {
        crate::item_data::canon_tag(&Tag::Compound(patch.clone()))
    }

    #[test]
    fn a_native_entity_item_merges_opaque_data_without_replacing_its_identity() {
        let fresh = snbt(
            "{id:\"example:heater\",x:4,y:65,z:8,fuel:1,\
             nested:{retained:17,changed:0},components:{}}",
        );
        let Tag::Compound(patch) = snbt(
            "{\"minecraft:block_entity_data\":{id:\"example:heater\",\
             x:99,y:99,z:99,fuel:923,nested:{changed:5},opaque:[B;1,-2,3]}}",
        ) else {
            unreachable!()
        };
        let placed = place(&fresh, &patch, false);
        assert_eq!(
            placed,
            snbt(
                "{id:\"example:heater\",x:4,y:65,z:8,fuel:923,\
                 nested:{retained:17,changed:5},opaque:[B;1,-2,3],components:{}}"
            )
        );
        let Tag::Compound(other_type) =
            snbt("{\"minecraft:block_entity_data\":{id:\"example:other\",fuel:888}}")
        else {
            unreachable!()
        };
        assert_eq!(place(&fresh, &other_type, false), fresh);
        assert_eq!(place(&fresh, &pick(&placed), false), placed);
    }

    #[test]
    fn a_filled_named_chest_gives_its_items_and_name_as_components() {
        let chest = saved(
            "{id:\"minecraft:chest\",x:1,y:2,z:3,CustomName:\"Loot\",\
             Items:[{Slot:4b,id:\"minecraft:stone\",count:5}]}",
        );
        let patch = pick(&chest);
        assert_eq!(
            canon(&patch),
            crate::item_data::canon_tag(&snbt(
                "{\"minecraft:container\":[{slot:4,item:{id:\"minecraft:stone\",count:5}}],\
                 \"minecraft:custom_name\":\"Loot\"}"
            ))
        );
        // Placing it back gives the same chest.
        let empty = saved("{id:\"minecraft:chest\",x:1,y:2,z:3}");
        assert_eq!(place(&empty, &patch, false), chest);
        // An empty chest has nothing to carry.
        assert!(pick(&empty).is_empty());
    }

    #[test]
    fn a_command_block_keeps_its_command_in_block_entity_data() {
        let block = saved(
            "{id:\"minecraft:command_block\",x:0,y:0,z:0,Command:\"say hi\",auto:1b,powered:1b}",
        );
        let patch = pick(&block);
        let data = patch
            .get(&JavaString::from(BLOCK_ENTITY_DATA))
            .expect("data");
        assert_eq!(data.get("Command"), Some(&Tag::String("say hi".into())));
        assert_eq!(data.get("powered"), None);
        assert_eq!(
            data.get("id"),
            Some(&Tag::String("minecraft:command_block".into()))
        );
        // Only a player who can use game master blocks places it.
        let fresh = saved("{id:\"minecraft:command_block\",x:0,y:0,z:0}");
        assert_eq!(place(&fresh, &patch, false), fresh);
        assert_eq!(
            place(&fresh, &patch, true).get("Command"),
            Some(&Tag::String("say hi".into()))
        );
        // Data of another type is ignored.
        let chest = saved("{id:\"minecraft:chest\",x:0,y:0,z:0}");
        assert_eq!(place(&chest, &patch, true), chest);
    }

    #[test]
    #[ignore = "daily"]
    fn a_mod_block_entity_rides_its_item() {
        // The declared types are frozen once per process: install them in a fresh one.
        const CHILD: &str = "HORIZON_TEST_MOD_BLOCK_ENTITY_ITEM";
        if std::env::var_os(CHILD).is_none() {
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--include-ignored",
                    "--exact",
                    "block_entity_item::tests::a_mod_block_entity_rides_its_item",
                    "--nocapture",
                ])
                .env(CHILD, "1")
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "test=block_entity_item::tests::a_mod_block_entity_rides_its_item exit_code={:?} category=fixture-child-failed",
                output.status.code()
            );
            return;
        }
        use crate::block_entity_types::{self, BlockEntityTypes};
        block_entity_types::install(BlockEntityTypes::new(
            [
                ("example:crate".into(), "example:crate".into()),
                ("example:tank".into(), "example:tank".into()),
            ]
            .into(),
            vec!["example:crate".into(), "example:tank".into()],
        ))
        .unwrap();
        // A named crate: its custom name is its own component patch.
        let tank = saved(
            "{id:\"example:crate\",x:3,y:4,z:5,Fluid:\"minecraft:water\",Amount:2000,\
             components:{\"minecraft:custom_name\":\"Box\"}}",
        );
        let patch = pick(&tank);
        let data = patch
            .get(&JavaString::from(BLOCK_ENTITY_DATA))
            .expect("data");
        assert_eq!(data.get("Amount"), Some(&Tag::Int(2000)));
        assert_eq!(data.get("id"), Some(&Tag::String("example:crate".into())));
        // `saveCustomOnly`: no position and no components in the data; the
        // patch goes to the item's own components (`collectComponents`).
        assert_eq!(data.get("x"), None);
        assert_eq!(data.get("components"), None);
        assert_eq!(
            patch.get(&JavaString::from("minecraft:custom_name")),
            Some(&Tag::String("Box".into()))
        );
        let fresh = saved("{id:\"example:crate\",x:9,y:9,z:9}");
        let placed = place(&fresh, &patch, false);
        assert_eq!(placed.get("Amount"), Some(&Tag::Int(2000)));
        assert_eq!(placed.get("x"), Some(&Tag::Int(9)));
        // The item's name becomes the block entity's own component again.
        assert_eq!(
            placed
                .get("components")
                .and_then(|c| c.get("minecraft:custom_name")),
            Some(&Tag::String("Box".into()))
        );
        // An item without a patch places no empty one, as a chunk saves it.
        let mut bare = patch.clone();
        bare.remove(&JavaString::from("minecraft:custom_name"));
        assert_eq!(place(&fresh, &bare, false).get("components"), None);
        // Another type's data is ignored.
        let other = saved("{id:\"example:tank\",x:9,y:9,z:9}");
        assert_eq!(place(&other, &patch, false).get("Amount"), None);
        // An undeclared type has no saved form.
        assert_eq!(canonical(&snbt("{id:\"example:nope\",x:0,y:0,z:0}")), None);
    }

    #[test]
    fn a_spawn_egg_sets_its_data_type_and_an_ops_data() {
        let egg = |entity_data: Option<&str>| {
            let mut stack = crate::items::ItemStack::new("minecraft:zombie_spawn_egg", 1);
            if let Some(text) = entity_data {
                let components = snbt(&format!("{{\"minecraft:entity_data\":{text}}}"));
                (stack.damage, stack.extra) =
                    crate::item_data::decode_components(Some(&components));
            }
            stack
        };
        // A plain egg: its own type, no data, op or not.
        assert_eq!(
            spawn_egg_on_spawner(&egg(None), true),
            ("minecraft:zombie".into(), None)
        );
        // Entity data: its type for anyone (getType), its data only for an op.
        let custom = egg(Some("{id:\"minecraft:skeleton\",CustomName:\"Guard\"}"));
        let (id, data) = spawn_egg_on_spawner(&custom, false);
        assert_eq!((id.as_str(), data), ("minecraft:skeleton", None));
        let (id, data) = spawn_egg_on_spawner(&custom, true);
        assert_eq!(id, "minecraft:skeleton");
        let data = data.expect("an op's egg carries its data");
        assert_eq!(
            data.get(&JavaString::from("CustomName")),
            Some(&Tag::String("Guard".into()))
        );
    }

    #[test]
    fn a_placed_entity_takes_the_items_custom_data_and_matching_entity_data() {
        let item = |components: &str| {
            let components = snbt(components);
            let (damage, extra) = crate::item_data::decode_components(Some(&components));
            crate::items::ItemStack {
                damage,
                extra,
                ..crate::items::ItemStack::new("minecraft:armor_stand", 1)
            }
        };
        let own = snbt("{CustomName:\"Named\",ShowArms:0b}");
        let stack = item(
            "{\"minecraft:custom_data\":{k:1b},\"minecraft:entity_data\":{id:\"minecraft:armor_stand\",ShowArms:1b}}",
        );
        let tag = stack_configured_entity(&stack, "minecraft:armor_stand", &own);
        assert_eq!(tag.get("ShowArms"), Some(&Tag::Byte(1)));
        assert_eq!(tag.get("CustomName"), Some(&Tag::String("Named".into())));
        assert_eq!(
            tag.get("data").and_then(|d| d.get("k")),
            Some(&Tag::Byte(1))
        );
        // Data of another type is not loaded; the custom data still is.
        let tag = stack_configured_entity(&stack, "minecraft:item_frame", &own);
        assert_eq!(tag.get("ShowArms"), Some(&Tag::Byte(0)));
        assert!(tag.get("data").is_some());
    }

    #[test]
    fn a_spawn_egg_data_needs_its_own_type_and_an_op_for_an_op_only_one() {
        let egg = |entity_data: &str| {
            let components = snbt(&format!("{{\"minecraft:entity_data\":{entity_data}}}"));
            let (damage, extra) = crate::item_data::decode_components(Some(&components));
            crate::items::ItemStack {
                damage,
                extra,
                ..crate::items::ItemStack::new("minecraft:zombie_spawn_egg", 1)
            }
        };
        // `entity_data` without an id names the egg's own type: applied for anyone.
        let own = egg("{NoAI:1b}");
        assert_eq!(
            spawn_egg_entity_data(&own, "minecraft:zombie", false)
                .and_then(|data| data.get("NoAI")),
            Some(&Tag::Byte(1))
        );
        // `entity_data.id` names another type: the spawned type keeps no data.
        let other = egg("{id:\"minecraft:pig\",NoAI:1b}");
        assert_eq!(
            spawn_egg_entity_data(&other, "minecraft:zombie", false),
            None
        );
        // An op-only type's data needs an op.
        assert_eq!(
            spawn_egg_entity_data(&own, "minecraft:falling_block", false),
            None
        );
        assert!(spawn_egg_entity_data(&own, "minecraft:falling_block", true).is_some());
    }

    #[test]
    fn item_data_names_its_spawn_and_op_only_types() {
        let item = |text: &str| {
            let components = snbt(&format!("{{\"minecraft:block_entity_data\":{text}}}"));
            let (damage, extra) = crate::item_data::decode_components(Some(&components));
            crate::items::ItemStack {
                damage,
                extra,
                ..crate::items::ItemStack::new("minecraft:spawner", 1)
            }
        };
        let spawner =
            item("{id:\"minecraft:mob_spawner\",SpawnData:{entity:{id:\"minecraft:zombie\"}}}");
        assert_eq!(
            spawner_entity(&spawner).as_deref(),
            Some("minecraft:zombie")
        );
        assert!(op_warning(&spawner));
        let chest = item("{id:\"minecraft:chest\",LootTable:\"x\"}");
        assert_eq!(spawner_entity(&chest), None);
        assert!(!op_warning(&chest));
    }

    /// `JukeboxBlock.setPlacedBy` looks for a `RecordItem` in the placed
    /// item's block entity data, whatever the type it names: only that key
    /// turns the box's `has_record` on.
    #[test]
    fn a_jukebox_item_with_a_record_in_its_data_says_so() {
        let jukebox = |text: &str| {
            let components = snbt(&format!("{{\"minecraft:block_entity_data\":{text}}}"));
            let (damage, extra) = crate::item_data::decode_components(Some(&components));
            crate::items::ItemStack {
                damage,
                extra,
                ..crate::items::ItemStack::new("minecraft:jukebox", 1)
            }
        };
        // A plain jukebox, and one whose data is only the type id: no record.
        assert!(!carries_record(&crate::items::ItemStack::new(
            "minecraft:jukebox",
            1
        )));
        assert!(!carries_record(&jukebox("{id:\"minecraft:jukebox\"}")));
        assert!(!carries_record(&jukebox(
            "{id:\"minecraft:jukebox\",Items:[{Slot:0b,id:\"minecraft:stone\",count:1}]}"
        )));
        // Creative's Ctrl + Pick Block on a jukebox holding a disc.
        assert!(carries_record(&jukebox(
            "{id:\"minecraft:jukebox\",RecordItem:{id:\"minecraft:music_disc_cat\",count:1}}"
        )));
        // The key alone counts: `TypedEntityData.contains` never checks the
        // type, and the state it sets is the one the block is placed as.
        assert!(carries_record(&jukebox(
            "{id:\"minecraft:chest\",RecordItem:{id:\"minecraft:music_disc_cat\",count:1}}"
        )));
    }

    #[test]
    fn a_written_sign_gives_its_text_and_wax() {
        let sign = saved(
            "{id:\"minecraft:sign\",x:0,y:0,z:0,is_waxed:1b,\
             front_text:{messages:[\"a\",\"b\",\"\",\"\"]}}",
        );
        let patch = pick(&sign);
        let keys: Vec<String> = patch.keys().map(|k| k.to_string_lossy()).collect();
        assert_eq!(keys, ["minecraft:sign_text_front", "minecraft:waxed"]);
        let fresh = saved("{id:\"minecraft:sign\",x:0,y:0,z:0}");
        assert_eq!(place(&fresh, &patch, false), sign);
    }

    /// A content sign's block entity starts with its declared colour and glow. An item with
    /// no sign text leaves them; an item with sign text replaces them.
    #[test]
    fn a_placed_sign_keeps_the_declared_text_unless_the_item_carries_text() {
        let declared = saved(
            "{id:\"minecraft:sign\",x:0,y:0,z:0,\
             front_text:{messages:[\"\",\"\",\"\",\"\"],color:\"light_blue\",has_glowing_text:1b}}",
        );
        let bare = place(&declared, &Compound::new(), false);
        let color = |tag: &Tag| tag.get("front_text").and_then(|t| t.get("color")).cloned();
        assert_eq!(color(&bare), color(&declared));
        assert_eq!(color(&bare), Some(Tag::String("light_blue".into())));

        let written = saved(
            "{id:\"minecraft:sign\",x:0,y:0,z:0,\
             front_text:{messages:[\"a\",\"\",\"\",\"\"],color:\"red\"}}",
        );
        let placed = place(&declared, &pick(&written), false);
        assert_eq!(color(&placed), Some(Tag::String("red".into())));
    }
}
