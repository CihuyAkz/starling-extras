//! Horizon's optional extras (lighting, inventory tools): their
//! settings, kept in `horizon-extras.txt` next to `options.txt` so that file
//! stays exactly vanilla's, and the logic behind them. Most opt-in features are
//! off by default; existing Android frame hints remain on to preserve behavior.
//! Horizon's own switches outside the Extras page (No AI, Agent Control,
//! Discord Rich Presence) are kept here too.
use std::{collections::VecDeque, fs, path::Path};

pub const FILE: &str = "horizon-extras.txt";
/// The name the options screen uses while the sort key waits for a key.
pub const SORT_KEY: &str = "horizon.sort";

/// A screen corner for an overlay.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Corner {
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
}
impl Corner {
    pub const ALL: [Corner; 4] = [
        Corner::TopLeft,
        Corner::TopRight,
        Corner::BottomLeft,
        Corner::BottomRight,
    ];
    pub fn name(self) -> &'static str {
        match self {
            Corner::TopLeft => "top_left",
            Corner::TopRight => "top_right",
            Corner::BottomLeft => "bottom_left",
            Corner::BottomRight => "bottom_right",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            Corner::TopLeft => "Top left",
            Corner::TopRight => "Top right",
            Corner::BottomLeft => "Bottom left",
            Corner::BottomRight => "Bottom right",
        }
    }
    fn parse(s: &str, default: Corner) -> Corner {
        Self::ALL
            .into_iter()
            .find(|c| c.name() == s)
            .unwrap_or(default)
    }
    pub fn top(self) -> bool {
        matches!(self, Corner::TopLeft | Corner::TopRight)
    }
    pub fn left(self) -> bool {
        matches!(self, Corner::TopLeft | Corner::BottomLeft)
    }
}

/// Performance switches shown on Mods > Starling Extras > Extra Feature.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Optimization {
    FastBackground,
    MenuBackground,
    GameAnimations,
    FastChunkUpload,
    BatteryPerformance,
    MaxFps,
    AndroidPerformanceHints,
}
impl Optimization {
    pub fn label(self) -> &'static str {
        match self {
            Self::FastBackground => "Fast Background",
            Self::MenuBackground => "Reduce Menu Background Blur",
            Self::GameAnimations => "Disable Game Animations",
            Self::FastChunkUpload => "Fast Chunk Mesh Upload",
            Self::BatteryPerformance => "Battery Performance (60 FPS)",
            Self::MaxFps => "Maximum FPS Mode",
            Self::AndroidPerformanceHints => "Android Performance Hints",
        }
    }
    pub fn description(self) -> &'static str {
        match self {
            Self::FastBackground => {
                "Caches the last gameplay scene in a GPU texture. In an in-world menu, Starling reuses that frozen image and draws only the menu UI, skipping the 3D world render. The cache refreshes during gameplay; the first menu frame builds it. GPU texture-copy support is required; unsupported devices keep normal rendering."
            }
            Self::MenuBackground => {
                "Skip the blurred gameplay or panorama background while a menu is open."
            }
            Self::GameAnimations => {
                "Disable animated textures, chunk fade and view bobbing without changing saved graphics settings; also disables Android menu motion where supported."
            }
            Self::FastChunkUpload => {
                "Raise the per-frame chunk mesh upload budget to at least 4 MiB."
            }
            Self::BatteryPerformance => {
                "Limit the effective frame rate to 60 FPS to reduce power use."
            }
            Self::MaxFps => {
                "Disable VSync and remove the configured frame-rate cap (in-game inactivity limits still apply)."
            }
            Self::AndroidPerformanceHints => {
                "Send CPU frame-time hints to Android's Dynamic Performance Framework."
            }
        }
    }
    pub fn enabled(self, extras: &Extras) -> bool {
        match self {
            Self::FastBackground => extras.fast_background,
            Self::MenuBackground => extras.menu_background_optimization,
            Self::GameAnimations => extras.disable_game_animations,
            Self::FastChunkUpload => extras.fast_chunk_upload,
            Self::BatteryPerformance => extras.battery_performance,
            Self::MaxFps => extras.max_fps_mode,
            Self::AndroidPerformanceHints => extras.android_performance_hints,
        }
    }
    pub fn toggle(self, extras: &mut Extras) {
        match self {
            Self::FastBackground => extras.fast_background = !extras.fast_background,
            Self::MenuBackground => {
                extras.menu_background_optimization = !extras.menu_background_optimization
            }
            Self::GameAnimations => {
                extras.disable_game_animations = !extras.disable_game_animations
            }
            Self::FastChunkUpload => extras.fast_chunk_upload = !extras.fast_chunk_upload,
            Self::BatteryPerformance => {
                extras.battery_performance = !extras.battery_performance;
                if extras.battery_performance {
                    extras.max_fps_mode = false;
                }
            }
            Self::MaxFps => {
                extras.max_fps_mode = !extras.max_fps_mode;
                if extras.max_fps_mode {
                    extras.battery_performance = false;
                }
            }
            Self::AndroidPerformanceHints => {
                extras.android_performance_hints = !extras.android_performance_hints
            }
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Extras {
    pub fullbright: bool,
    /// Held, dropped and burning light sources light their surroundings (`dynamic_light`).
    pub dynamic_lights: bool,
    pub zoom: bool,
    /// A vanilla key name (`key.keyboard.z`).
    pub zoom_key: String,
    /// The zoom the key starts at.
    pub zoom_level: u8,
    /// Ease through vanilla's FOV easing (as the spyglass does).
    pub zoom_smooth: bool,
    /// Divide mouse turning by the zoom.
    pub zoom_sensitivity: bool,
    /// The FPS counter and keystrokes extras are official mods now: their
    /// old settings stay here, kept as they were.
    pub fps: bool,
    pub fps_corner: Corner,
    /// Also show the minimum and 1% low.
    pub fps_lows: bool,
    pub keystrokes: bool,
    pub keystrokes_corner: Corner,
    /// Clicks per second under the mouse buttons.
    pub keystrokes_cps: bool,
    /// The official mods once installed for the extras they replace, by mod
    /// id (`movedToMods`).
    pub moved: Vec<String>,
    /// Retry lost multiplayer connections (`reconnect`).
    pub auto_reconnect: bool,
    /// Positional sounds leave a few static sound channels free for UI sounds
    /// and others played to the listener (`sound_engine::HEARD_RESERVE`).
    pub ui_sound_reserve: bool,
    /// The player's own name tag over its model in third person.
    pub own_name_tag: bool,
    /// No particles from breaking or mining a block (other particles stay).
    pub hide_block_particles: bool,
    /// Mouse Tweaks-style drags in the inventory and storage containers.
    pub mouse_tweaks: bool,
    /// With them, the wheel over a slot moves its items one at a time.
    pub mouse_tweaks_wheel: bool,
    /// Sort buttons on the inventory and chest-like containers.
    pub sort: bool,
    /// A vanilla key name: sorts the part under the cursor.
    pub sort_key: String,
    /// A new chat line slides in from the left while it fades in (`Chat::layout`).
    pub chat_animation: bool,
    /// The indicator bar at the left of a chat line (on by default, as vanilla).
    pub chat_indicator: bool,
    /// No AI: every AI feature hidden and off (`horizon_core::no_ai`; the launcher writes it too).
    pub no_ai: bool,
    /// Agents may control the game the player starts: it opens its control socket for
    /// horizon-ctl and MCP clients (off by default; an agent's own launch always opens it).
    pub agent_control: bool,
    /// F3+R and F3+E start/stop a repro recording and write its bundle (off by
    /// default: a recording copies the world).
    pub repro_keys: bool,
    /// "Playing Horizon" on the player's Discord profile (`discord_presence`; on by default).
    pub discord_presence: bool,
    /// Another controller can join P1's world (`splitscreen`, off by default).
    pub splitscreen: bool,
    /// Two players in one window: 0 auto (side by side when wider than tall), 1 side by side,
    /// 2 top and bottom (`splitscreenTwo`).
    pub splitscreen_two: u8,
    /// Three players on a screen: 0 one wide on top, 1 one tall on the left, 2 side by side
    /// (`splitscreenThree`).
    pub splitscreen_three: u8,
    /// Splitscreen: each player's name in the corner of their view (`splitscreenNames`).
    pub splitscreen_names: bool,
    /// The wheel over a cycle button in the settings changes it (`CycleButton.mouseScrolled`,
    /// on by default as vanilla); off, the wheel only scrolls the list.
    pub wheel_cycles_settings: bool,
    /// The built-in music tracks the Music page turned off (sound ids): they
    /// leave every pool they play in (`musicOff`, empty by default: vanilla's
    /// random selection).
    pub music_off: Vec<String>,
    /// The Music page: the Music... button on Music & Sounds, playing a
    /// built-in track and leaving the off ones out (`musicPage`, off by
    /// default: vanilla plays exactly as before).
    pub music_page: bool,
    /// Cosmetics (`horizon_cosmetics`, off unless enabled): the player's own, and the other
    /// players' (`cosmeticsMine`, `cosmeticsOthers`; both on by default).
    pub cosmetics_mine: bool,
    pub cosmetics_others: bool,
    /// Reuse the last gameplay scene as a static GPU-cached menu background.
    pub fast_background: bool,
    /// Reduce the cost of menus by skipping the blurred gameplay/panorama background.
    pub menu_background_optimization: bool,
    /// Disable animated textures, chunk fade and view bobbing while preserving their saved values.
    pub disable_game_animations: bool,
    /// Allow up to 4 MiB of chunk mesh uploads per frame, unless a higher budget is set.
    pub fast_chunk_upload: bool,
    /// Cap the effective frame rate at 60 FPS to reduce power use.
    pub battery_performance: bool,
    /// Use the highest frame-rate limit instead of the configured cap.
    pub max_fps_mode: bool,
    /// Android Dynamic Performance Framework frame hints (enabled by default, as before).
    pub android_performance_hints: bool,
}
impl Default for Extras {
    fn default() -> Self {
        Self {
            fullbright: false,
            dynamic_lights: false,
            zoom: false,
            zoom_key: "key.keyboard.z".into(),
            zoom_level: 4,
            zoom_smooth: true,
            zoom_sensitivity: true,
            fps: false,
            fps_corner: Corner::TopLeft,
            fps_lows: false,
            keystrokes: false,
            keystrokes_corner: Corner::TopLeft,
            keystrokes_cps: true,
            moved: Vec::new(),
            auto_reconnect: false,
            ui_sound_reserve: false,
            own_name_tag: false,
            hide_block_particles: false,
            mouse_tweaks: false,
            mouse_tweaks_wheel: true,
            sort: false,
            sort_key: "key.keyboard.unknown".into(),
            chat_animation: false,
            chat_indicator: true,
            no_ai: false,
            agent_control: false,
            repro_keys: false,
            discord_presence: true,
            splitscreen: false,
            splitscreen_two: 0,
            splitscreen_three: 0,
            splitscreen_names: true,
            wheel_cycles_settings: true,
            music_off: Vec::new(),
            music_page: false,
            cosmetics_mine: true,
            cosmetics_others: true,
            fast_background: false,
            menu_background_optimization: false,
            disable_game_animations: false,
            fast_chunk_upload: false,
            battery_performance: false,
            max_fps_mode: false,
            android_performance_hints: true,
        }
    }
}
fn bool_text(v: bool) -> &'static str {
    if v { "true" } else { "false" }
}
impl Extras {
    /// Counts optional boosts, treating battery and maximum-FPS modes as alternatives.
    /// Android frame hints are excluded because they already run by default in Starling.
    pub fn optimization_level(&self) -> usize {
        self.fast_background as usize
            + self.menu_background_optimization as usize
            + self.disable_game_animations as usize
            + self.fast_chunk_upload as usize
            + (self.battery_performance || self.max_fps_mode) as usize
    }
    pub fn load(dir: &Path) -> Self {
        fs::read_to_string(dir.join(FILE))
            .map(|t| Self::parse(&t))
            .unwrap_or_default()
    }
    pub fn parse(text: &str) -> Self {
        let mut e = Self::default();
        for line in text.lines() {
            let Some((key, value)) = line.split_once(':') else {
                continue;
            };
            let value = value.trim();
            let flag = |d: bool| match value {
                "true" => true,
                "false" => false,
                _ => d,
            };
            match key.trim() {
                "fullbright" => e.fullbright = flag(e.fullbright),
                "dynamicLights" => e.dynamic_lights = flag(e.dynamic_lights),
                "zoom" => e.zoom = flag(e.zoom),
                "zoomKey" if value.starts_with("key.") => e.zoom_key = value.to_owned(),
                "zoomLevel" => {
                    if let Ok(v) = value.parse::<u8>() {
                        e.zoom_level = v.clamp(2, 10);
                    }
                }
                "zoomSmooth" => e.zoom_smooth = flag(e.zoom_smooth),
                "zoomSensitivity" => e.zoom_sensitivity = flag(e.zoom_sensitivity),
                "fps" => e.fps = flag(e.fps),
                "fpsCorner" => e.fps_corner = Corner::parse(value, e.fps_corner),
                "fpsLows" => e.fps_lows = flag(e.fps_lows),
                "keystrokes" => e.keystrokes = flag(e.keystrokes),
                "keystrokesCorner" => {
                    e.keystrokes_corner = Corner::parse(value, e.keystrokes_corner)
                }
                "keystrokesCps" => e.keystrokes_cps = flag(e.keystrokes_cps),
                "movedToMods" => {
                    e.moved = value
                        .split(',')
                        .map(str::trim)
                        .filter(|id| !id.is_empty())
                        .map(str::to_owned)
                        .collect()
                }
                "autoReconnect" => e.auto_reconnect = flag(e.auto_reconnect),
                "uiSoundReserve" => e.ui_sound_reserve = flag(e.ui_sound_reserve),
                "ownNameTag" => e.own_name_tag = flag(e.own_name_tag),
                "hideBlockParticles" => e.hide_block_particles = flag(e.hide_block_particles),
                "mouseTweaks" => e.mouse_tweaks = flag(e.mouse_tweaks),
                "mouseTweaksWheel" => e.mouse_tweaks_wheel = flag(e.mouse_tweaks_wheel),
                "sort" => e.sort = flag(e.sort),
                "sortKey" if value.starts_with("key.") => e.sort_key = value.to_owned(),
                "chatAnimation" => e.chat_animation = flag(e.chat_animation),
                "chatIndicator" => e.chat_indicator = flag(e.chat_indicator),
                horizon_core::no_ai::KEY => e.no_ai = flag(e.no_ai),
                "agentControl" => e.agent_control = flag(e.agent_control),
                "reproKeys" => e.repro_keys = flag(e.repro_keys),
                "discordPresence" => e.discord_presence = flag(e.discord_presence),
                "splitscreen" => e.splitscreen = flag(e.splitscreen),
                "splitscreenTwo" => e.splitscreen_two = value.parse().unwrap_or(0).min(2),
                "splitscreenThree" => e.splitscreen_three = value.parse().unwrap_or(0).min(2),
                "splitscreenNames" => e.splitscreen_names = flag(e.splitscreen_names),
                "wheelCyclesSettings" => e.wheel_cycles_settings = flag(e.wheel_cycles_settings),
                "musicOff" => {
                    e.music_off = value
                        .split(',')
                        .map(str::trim)
                        .filter(|id| !id.is_empty())
                        .map(str::to_owned)
                        .collect()
                }
                "musicPage" => e.music_page = flag(e.music_page),
                "cosmeticsMine" => e.cosmetics_mine = flag(e.cosmetics_mine),
                "cosmeticsOthers" => e.cosmetics_others = flag(e.cosmetics_others),
                "fastBackground" => e.fast_background = flag(e.fast_background),
                "menuBackgroundOptimization" => {
                    e.menu_background_optimization = flag(e.menu_background_optimization)
                }
                "disableGameAnimations" => {
                    e.disable_game_animations = flag(e.disable_game_animations)
                }
                "fastChunkUpload" => e.fast_chunk_upload = flag(e.fast_chunk_upload),
                "batteryPerformance" => e.battery_performance = flag(e.battery_performance),
                "maxFpsMode" => e.max_fps_mode = flag(e.max_fps_mode),
                "androidPerformanceHints" => {
                    e.android_performance_hints = flag(e.android_performance_hints)
                }
                _ => {}
            }
        }
        e
    }
    pub fn serialize(&self) -> String {
        format!(
            "fullbright:{}\ndynamicLights:{}\nzoom:{}\nzoomKey:{}\nzoomLevel:{}\nzoomSmooth:{}\nzoomSensitivity:{}\nfps:{}\nfpsCorner:{}\nfpsLows:{}\nkeystrokes:{}\nkeystrokesCorner:{}\nkeystrokesCps:{}\nmovedToMods:{}\nautoReconnect:{}\nuiSoundReserve:{}\nownNameTag:{}\nhideBlockParticles:{}\nmouseTweaks:{}\nmouseTweaksWheel:{}\nsort:{}\nsortKey:{}\nchatAnimation:{}\nchatIndicator:{}\n{}:{}\nagentControl:{}\nreproKeys:{}\ndiscordPresence:{}\nsplitscreen:{}\nsplitscreenTwo:{}\nsplitscreenThree:{}\nsplitscreenNames:{}\nwheelCyclesSettings:{}\nmusicOff:{}\nmusicPage:{}\ncosmeticsMine:{}\ncosmeticsOthers:{}\nfastBackground:{}\nmenuBackgroundOptimization:{}\ndisableGameAnimations:{}\nfastChunkUpload:{}\nbatteryPerformance:{}\nmaxFpsMode:{}\nandroidPerformanceHints:{}\n",
            bool_text(self.fullbright),
            bool_text(self.dynamic_lights),
            bool_text(self.zoom),
            self.zoom_key,
            self.zoom_level,
            bool_text(self.zoom_smooth),
            bool_text(self.zoom_sensitivity),
            bool_text(self.fps),
            self.fps_corner.name(),
            bool_text(self.fps_lows),
            bool_text(self.keystrokes),
            self.keystrokes_corner.name(),
            bool_text(self.keystrokes_cps),
            self.moved.join(","),
            bool_text(self.auto_reconnect),
            bool_text(self.ui_sound_reserve),
            bool_text(self.own_name_tag),
            bool_text(self.hide_block_particles),
            bool_text(self.mouse_tweaks),
            bool_text(self.mouse_tweaks_wheel),
            bool_text(self.sort),
            self.sort_key,
            bool_text(self.chat_animation),
            bool_text(self.chat_indicator),
            horizon_core::no_ai::KEY,
            bool_text(self.no_ai),
            bool_text(self.agent_control),
            bool_text(self.repro_keys),
            bool_text(self.discord_presence),
            bool_text(self.splitscreen),
            self.splitscreen_two,
            self.splitscreen_three,
            bool_text(self.splitscreen_names),
            bool_text(self.wheel_cycles_settings),
            self.music_off.join(","),
            bool_text(self.music_page),
            bool_text(self.cosmetics_mine),
            bool_text(self.cosmetics_others),
            bool_text(self.fast_background),
            bool_text(self.menu_background_optimization),
            bool_text(self.disable_game_animations),
            bool_text(self.fast_chunk_upload),
            bool_text(self.battery_performance),
            bool_text(self.max_fps_mode),
            bool_text(self.android_performance_hints),
        )
    }
    /// Binds the extra key `name` (`SORT_KEY`); false for
    /// another name (a vanilla mapping).
    pub fn set_key(&mut self, name: &str, value: String) -> bool {
        match name {
            SORT_KEY => self.sort_key = value,
            _ => return false,
        }
        true
    }
    /// Written only once something differs from the defaults, so a vanilla
    /// setup gains no file.
    pub fn save(&self, dir: &Path) {
        let path = dir.join(FILE);
        if *self == Self::default() && !path.exists() {
            return;
        }
        let _ = fs::write(path, self.serialize());
    }
}

/// The field-of-view modifier target `Camera.tickFov` eases toward: vanilla's
/// (`getFieldOfViewModifier`) divided by a mod's zoom (`native_zoom`). A
/// zoom of 1 leaves it as is.
pub fn fov_target(vanilla: f32, zoom: f32) -> f32 {
    if zoom == 1.0 { vanilla } else { vanilla / zoom }
}
/// Frame times over the last few seconds: frames per second, the minimum
/// and the 1% low, recomputed twice a second.
pub struct FpsCounter {
    /// (end time in seconds, frame milliseconds), oldest first.
    frames: VecDeque<(f64, f32)>,
    shown: FpsReading,
    computed_at: f64,
}
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct FpsReading {
    pub fps: u32,
    pub min: u32,
    pub low: u32,
}
/// Seconds the minimum and 1% low look back.
const LOW_WINDOW: f64 = 5.0;
impl Default for FpsCounter {
    fn default() -> Self {
        Self {
            frames: VecDeque::new(),
            shown: FpsReading::default(),
            computed_at: f64::NEG_INFINITY,
        }
    }
}
impl FpsCounter {
    /// A frame that ended at `now` (seconds) and took `ms`.
    pub fn record(&mut self, now: f64, ms: f32) {
        self.frames.push_back((now, ms));
        while self
            .frames
            .front()
            .is_some_and(|&(t, _)| now - t > LOW_WINDOW)
        {
            self.frames.pop_front();
        }
        if now - self.computed_at >= 0.5 {
            self.computed_at = now;
            self.shown = self.compute(now);
        }
    }
    fn compute(&self, now: f64) -> FpsReading {
        let fps = self.frames.iter().filter(|&&(t, _)| now - t < 1.0).count() as u32;
        let mut times: Vec<f32> = self.frames.iter().map(|f| f.1).collect();
        if times.is_empty() {
            return FpsReading::default();
        }
        times.sort_by(|a, b| b.total_cmp(a));
        let to_fps = |ms: f32| (1000.0 / ms.max(0.001)).round() as u32;
        // The 1% low: the frame rate of the 99th percentile frame time.
        let low = times[(times.len() - 1) / 100];
        FpsReading {
            fps,
            min: to_fps(times[0]),
            low: to_fps(low),
        }
    }
    pub fn reading(&self) -> FpsReading {
        self.shown
    }
    pub fn clear(&mut self) {
        *self = Self::default();
    }
}

/// Clicks of one button in the last second.
#[derive(Default)]
pub struct Cps {
    clicks: VecDeque<f64>,
}
impl Cps {
    pub fn click(&mut self, now: f64) {
        self.clicks.push_back(now);
        self.forget(now);
    }
    fn forget(&mut self, now: f64) {
        while self.clicks.front().is_some_and(|&t| now - t >= 1.0) {
            self.clicks.pop_front();
        }
    }
    pub fn per_second(&mut self, now: f64) -> usize {
        self.forget(now);
        self.clicks.len()
    }
}
/// Two players sharing a window (`splitscreen_two`): halves this way.
pub const SPLIT_TWO: [&str; 3] = ["Auto", "Side by side", "Top and bottom"];
/// Three players sharing a window (`splitscreen_three`).
pub const SPLIT_THREE: [&str; 3] = ["One wide on top", "One tall on the left", "Side by side"];

/// The settings the Extras page shows, one per row.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Item {
    Fullbright,
    DynamicLights,
    OwnNameTag,
    HideBlockParticles,
    AutoReconnect,
    UiSoundReserve,
    /// The Music... page on Music & Sounds (`Music page`).
    MusicPage,
    MouseTweaks,
    MouseTweaksWheel,
    Sort,
    SortKey,
    /// A new chat line slides in and fades in (`Chat::layout`).
    ChatAnimation,
    /// The coloured bar at the left of a chat line.
    ChatIndicator,
    /// Not on the Extras page: Horizon Settings shows No AI, its AI Agent page Agent Control.
    NoAi,
    AgentControl,
    /// On the Horizon Settings page.
    DiscordPresence,
    /// On the AI Agent page, next to Agent Control: the F3 recording shortcuts.
    ReproKeys,
    /// On the Splitscreen settings page.
    Splitscreen,
    WheelCyclesSettings,
    /// Shown only while cosmetics are enabled (`horizon_cosmetics::enabled`).
    CosmeticsMine,
    CosmeticsOthers,
}
/// The Extras page: headers (language keys) and items.
pub fn rows() -> Vec<Result<Item, &'static str>> {
    use Item::*;
    let mut rows = vec![
        Err("horizon.extras.header.lighting"),
        Ok(Fullbright),
        Ok(DynamicLights),
        Err("horizon.extras.header.third_person"),
        Ok(OwnNameTag),
        Err("horizon.extras.header.particles"),
        Ok(HideBlockParticles),
        Err("horizon.extras.header.inventory"),
        Ok(MouseTweaks),
        Ok(MouseTweaksWheel),
        Ok(Sort),
        Ok(SortKey),
        Err("horizon.extras.header.chat"),
        Ok(ChatAnimation),
        Ok(ChatIndicator),
        Err("horizon.extras.header.multiplayer"),
        Ok(AutoReconnect),
        Err("horizon.extras.header.sound"),
        Ok(UiSoundReserve),
        Ok(MusicPage),
        Err("horizon.extras.header.menus"),
        Ok(WheelCyclesSettings),
    ];
    if horizon_cosmetics::enabled() {
        rows.extend([
            Err("horizon.extras.header.cosmetics"),
            Ok(CosmeticsMine),
            Ok(CosmeticsOthers),
        ]);
    }
    rows
}
impl Item {
    /// The language key of the caption (`horizon.*`, assets/horizon/lang).
    pub fn caption_key(self) -> &'static str {
        match self {
            Item::Fullbright => "horizon.extras.fullbright",
            Item::DynamicLights => "horizon.extras.dynamic_lights",
            Item::OwnNameTag => "horizon.extras.own_name_tag",
            Item::HideBlockParticles => "horizon.extras.hide_block_particles",
            Item::AutoReconnect => "horizon.extras.auto_reconnect",
            Item::UiSoundReserve => "horizon.extras.ui_sound_reserve",
            Item::MusicPage => "horizon.extras.music_page",
            Item::MouseTweaks => "horizon.extras.mouse_tweaks",
            Item::MouseTweaksWheel => "horizon.extras.mouse_tweaks_wheel",
            Item::Sort => "horizon.extras.sort",
            Item::SortKey => "horizon.extras.sort_key",
            Item::NoAi => "horizon.extras.no_ai",
            Item::AgentControl => "horizon.extras.agent_control",
            Item::ReproKeys => "horizon.extras.repro_keys",
            Item::DiscordPresence => "horizon.extras.discord_presence",
            Item::Splitscreen => "horizon.extras.splitscreen",
            Item::ChatAnimation => "horizon.extras.chat_animation",
            Item::ChatIndicator => "horizon.extras.chat_indicator",
            Item::WheelCyclesSettings => "horizon.extras.wheel_cycles_settings",
            Item::CosmeticsMine => "horizon.extras.cosmetics_mine",
            Item::CosmeticsOthers => "horizon.extras.cosmetics_others",
        }
    }
    /// The language key of the description shown as the row's tooltip.
    pub fn description_key(self) -> &'static str {
        match self {
            Item::Fullbright => "horizon.extras.fullbright.tooltip",
            Item::DynamicLights => "horizon.extras.dynamic_lights.tooltip",
            Item::OwnNameTag => "horizon.extras.own_name_tag.tooltip",
            Item::HideBlockParticles => "horizon.extras.hide_block_particles.tooltip",
            Item::AutoReconnect => "horizon.extras.auto_reconnect.tooltip",
            Item::UiSoundReserve => "horizon.extras.ui_sound_reserve.tooltip",
            Item::MusicPage => "horizon.extras.music_page.tooltip",
            Item::MouseTweaks => "horizon.extras.mouse_tweaks.tooltip",
            Item::MouseTweaksWheel => "horizon.extras.mouse_tweaks_wheel.tooltip",
            Item::Sort => "horizon.extras.sort.tooltip",
            Item::SortKey => "horizon.extras.sort_key.tooltip",
            Item::NoAi => "horizon.extras.no_ai.tooltip",
            Item::AgentControl => "horizon.extras.agent_control.tooltip",
            Item::ReproKeys => "horizon.extras.repro_keys.tooltip",
            Item::DiscordPresence => "horizon.extras.discord_presence.tooltip",
            Item::Splitscreen => "horizon.extras.splitscreen.tooltip",
            Item::ChatAnimation => "horizon.extras.chat_animation.tooltip",
            Item::ChatIndicator => "horizon.extras.chat_indicator.tooltip",
            Item::WheelCyclesSettings => "horizon.extras.wheel_cycles_settings.tooltip",
            Item::CosmeticsMine => "horizon.extras.cosmetics_mine.tooltip",
            Item::CosmeticsOthers => "horizon.extras.cosmetics_others.tooltip",
        }
    }
    /// The caption in the current language (English when the key is missing).
    pub fn caption_text(self) -> String {
        crate::lang::get_or(self.caption_key(), self.caption())
    }
    /// The description in the current language (English when the key is missing).
    pub fn description_text(self) -> String {
        crate::lang::get_or(self.description_key(), self.description())
    }
    /// The English caption: the fallback of [`Item::caption_text`], and the text of
    /// `horizon.extras.*` in en_us.json.
    pub fn caption(self) -> &'static str {
        match self {
            Item::Fullbright => "Fullbright",
            Item::DynamicLights => "Dynamic lights",
            Item::OwnNameTag => "Own name tag",
            Item::HideBlockParticles => "Hide block-break particles",
            Item::AutoReconnect => "Auto-reconnect",
            Item::UiSoundReserve => "Keep channels for UI sounds",
            Item::MusicPage => "Music page",
            Item::MouseTweaks => "Mouse Tweaks controls",
            Item::MouseTweaksWheel => "Scroll wheel moves items",
            Item::Sort => "Sort buttons",
            Item::SortKey => "Sort key",
            Item::ChatAnimation => "Smooth chat",
            Item::ChatIndicator => "Message indicator",
            Item::NoAi => "No AI",
            Item::AgentControl => "Agent Control",
            Item::ReproKeys => "Recording shortcuts",
            Item::DiscordPresence => "Discord Rich Presence",
            Item::Splitscreen => "Splitscreen",
            Item::WheelCyclesSettings => "Scroll wheel changes settings",
            Item::CosmeticsMine => "My cosmetics",
            Item::CosmeticsOthers => "Other players' cosmetics",
        }
    }
    /// The switch this setting belongs to: it does nothing while that is off.
    pub fn parent(self) -> Option<Item> {
        use Item::*;
        Some(match self {
            UiSoundReserve => return None,
            MouseTweaksWheel => MouseTweaks,
            SortKey => Sort,
            ChatIndicator => ChatAnimation,
            Fullbright | DynamicLights | OwnNameTag | HideBlockParticles | MouseTweaks | Sort
            | AutoReconnect | NoAi | AgentControl | ReproKeys | DiscordPresence | Splitscreen
            | ChatAnimation | WheelCyclesSettings | MusicPage | CosmeticsMine | CosmeticsOthers => {
                return None;
            }
        })
    }
    /// The English description: the fallback of [`Item::description_text`].
    pub fn description(self) -> &'static str {
        match self {
            Item::Fullbright => "Show blocks and entities at full light, even in dark areas.",
            Item::DynamicLights => {
                "Torches and other light sources held, dropped or on fire light the blocks around them."
            }
            Item::OwnNameTag => {
                "Shows your name above your head in third person, as other players see it. Hidden when the server hides your team's names or you're invisible."
            }
            Item::HideBlockParticles => {
                "Hides the debris particles that burst from a broken block and crumble off the one you mine. Other particles stay."
            }
            Item::AutoReconnect => {
                "Rejoins a server after a lost connection or a restart, never after a kick or ban."
            }
            Item::UiSoundReserve => {
                "Sounds in the world leave 16 of the 247 sound channels free, so a flood of them (a big explosion) can't silence menu clicks."
            }
            Item::MusicPage => {
                "Music & Sounds gets a Music... page: play any built-in track now, or turn one off so the game stops picking it. Nothing changes until you turn a track off."
            }
            Item::MouseTweaks => {
                "Right-drag places one per slot, left-drag gathers the held item, Shift + left-drag moves every slot."
            }
            Item::MouseTweaksWheel => {
                "Down sends one item of the slot to the other side, up brings one back."
            }
            Item::Sort => {
                "Sorts the inventory, chests, barrels, ender chests and shulker boxes in creative tab order, merging stacks."
            }
            Item::SortKey => {
                "Sorts the part under the cursor. Click, then press a key; Escape unbinds it."
            }
            Item::ChatAnimation => {
                "A new chat line slides in from the left while it fades in, instead of appearing whole."
            }
            Item::ChatIndicator => "The coloured bar at the left of a chat line.",
            Item::NoAi => {
                "Hides and turns off every AI feature: agent control, horizon-ctl and the MCP servers. The launcher's switch too."
            }
            Item::DiscordPresence => {
                "Shows Playing Horizon on your Discord profile while Discord runs: menus, single player or multiplayer, the dimension and the time played. Never a world's name or a server's address."
            }
            Item::Splitscreen => {
                "In a world, another controller can join as a new player: press A when it asks, then pick a profile and where to play."
            }
            Item::AgentControl => {
                "Your own AI agent can play this game through horizon-ctl or an MCP client, on this computer only."
            }
            Item::ReproKeys => {
                "F3+R starts or stops a repro recording and F3+E writes its bundle. Off by default: a recording copies the world."
            }
            Item::CosmeticsMine => {
                "Shows the cosmetics you wear on your own player, in third person and the inventory."
            }
            Item::CosmeticsOthers => {
                "Shows the cosmetics other Horizon players wear. Off, the game never asks what they wear."
            }
            Item::WheelCyclesSettings => {
                "The scroll wheel over a button in the settings changes its value, as in vanilla. Off, the wheel only scrolls the list."
            }
        }
    }
    /// The frame-time cost the main switch of an extra shows.
    pub fn cost(self) -> Option<crate::graphics_style::Cost> {
        use crate::graphics_style::Cost;
        match self {
            Item::Fullbright => Some(Cost::None),
            Item::UiSoundReserve => Some(Cost::None),
            Item::MusicPage => Some(Cost::None),
            Item::DynamicLights => Some(Cost::Low),
            Item::ChatAnimation => Some(Cost::None),
            Item::OwnNameTag
            | Item::HideBlockParticles
            | Item::AutoReconnect
            | Item::MouseTweaks
            | Item::Sort
            | Item::Splitscreen
            | Item::WheelCyclesSettings => Some(Cost::None),
            Item::CosmeticsMine | Item::CosmeticsOthers => Some(Cost::Low),
            _ => None,
        }
    }
    /// On/off items and their value.
    pub fn switch(self, e: &Extras) -> Option<bool> {
        Some(match self {
            Item::Fullbright => e.fullbright,
            Item::DynamicLights => e.dynamic_lights,
            Item::OwnNameTag => e.own_name_tag,
            Item::HideBlockParticles => e.hide_block_particles,
            Item::AutoReconnect => e.auto_reconnect,
            Item::UiSoundReserve => e.ui_sound_reserve,
            Item::MusicPage => e.music_page,
            Item::MouseTweaks => e.mouse_tweaks,
            Item::MouseTweaksWheel => e.mouse_tweaks_wheel,
            Item::Sort => e.sort,
            Item::ChatAnimation => e.chat_animation,
            Item::ChatIndicator => e.chat_indicator,
            Item::NoAi => e.no_ai,
            Item::AgentControl => e.agent_control,
            Item::ReproKeys => e.repro_keys,
            Item::DiscordPresence => e.discord_presence,
            Item::Splitscreen => e.splitscreen,
            Item::WheelCyclesSettings => e.wheel_cycles_settings,
            Item::CosmeticsMine => e.cosmetics_mine,
            Item::CosmeticsOthers => e.cosmetics_others,
            _ => return None,
        })
    }
    /// The value of the other items, as their button shows it.
    pub fn value(self, e: &Extras) -> String {
        match self {
            Item::SortKey => crate::keybinds::display_name(&e.sort_key).plain(),
            other => match other.switch(e) {
                Some(true) => crate::lang::get_or("On", "On"),
                _ => crate::lang::get_or("Off", "Off"),
            },
        }
    }
    /// A click (`_back` for the right button: every item left is a switch,
    /// so both flip it). The sort key binds instead.
    pub fn cycle(self, e: &mut Extras, _back: bool) {
        match self {
            Item::Fullbright => e.fullbright = !e.fullbright,
            Item::DynamicLights => e.dynamic_lights = !e.dynamic_lights,
            Item::OwnNameTag => e.own_name_tag = !e.own_name_tag,
            Item::HideBlockParticles => e.hide_block_particles = !e.hide_block_particles,
            Item::AutoReconnect => e.auto_reconnect = !e.auto_reconnect,
            Item::UiSoundReserve => e.ui_sound_reserve = !e.ui_sound_reserve,
            Item::MusicPage => e.music_page = !e.music_page,
            Item::MouseTweaks => e.mouse_tweaks = !e.mouse_tweaks,
            Item::MouseTweaksWheel => e.mouse_tweaks_wheel = !e.mouse_tweaks_wheel,
            Item::Sort => e.sort = !e.sort,
            Item::ChatAnimation => e.chat_animation = !e.chat_animation,
            Item::ChatIndicator => e.chat_indicator = !e.chat_indicator,
            Item::NoAi => e.no_ai = !e.no_ai,
            Item::AgentControl => e.agent_control = !e.agent_control,
            Item::ReproKeys => e.repro_keys = !e.repro_keys,
            Item::DiscordPresence => e.discord_presence = !e.discord_presence,
            Item::Splitscreen => e.splitscreen = !e.splitscreen,
            Item::WheelCyclesSettings => e.wheel_cycles_settings = !e.wheel_cycles_settings,
            Item::CosmeticsMine => e.cosmetics_mine = !e.cosmetics_mine,
            Item::CosmeticsOthers => e.cosmetics_others = !e.cosmetics_others,
            Item::SortKey => {}
        }
    }
    /// The key name the options screen waits on for a key item.
    pub fn key_name(self) -> Option<&'static str> {
        match self {
            Item::SortKey => Some(SORT_KEY),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_and_round_trips() {
        let d = Extras::default();
        assert!(!d.fullbright && !d.dynamic_lights);
        assert!(!d.zoom && !d.fps && !d.keystrokes && !d.auto_reconnect);
        assert!(!d.mouse_tweaks && !d.sort && !d.own_name_tag && !d.ui_sound_reserve);
        assert!(!d.hide_block_particles);
        assert!(!d.music_page && d.music_off.is_empty());
        assert!(d.discord_presence && d.wheel_cycles_settings);
        assert!(d.android_performance_hints);
        assert_eq!(d.optimization_level(), 0);
        assert_eq!(Extras::parse(""), d);
        assert_eq!(Extras::parse(&d.serialize()), d);
        let mut e = d.clone();
        Item::Fullbright.cycle(&mut e, false);
        assert_eq!(Item::Fullbright.switch(&e), Some(true));
        Item::DynamicLights.cycle(&mut e, false);
        assert_eq!(Item::DynamicLights.switch(&e), Some(true));
        assert_eq!(Extras::parse(&e.serialize()), e);
        e.zoom = true;
        e.zoom_key = "key.keyboard.c".into();
        e.zoom_level = 6;
        e.fps_corner = Corner::BottomRight;
        e.keystrokes = true;
        e.keystrokes_cps = false;
        e.moved = vec!["fps_overlay".into(), "keystrokes".into()];
        e.auto_reconnect = true;
        Item::OwnNameTag.cycle(&mut e, false);
        assert_eq!(Item::OwnNameTag.switch(&e), Some(true));
        assert_eq!(Item::HideBlockParticles.switch(&e), Some(false));
        Item::HideBlockParticles.cycle(&mut e, false);
        assert!(e.hide_block_particles);
        assert_eq!(Item::HideBlockParticles.switch(&e), Some(true));
        let only = Extras::parse("hideBlockParticles:true\n");
        assert!(only.hide_block_particles && !only.own_name_tag);
        e.mouse_tweaks = true;
        e.mouse_tweaks_wheel = false;
        e.sort = true;
        e.sort_key = "key.keyboard.r".into();
        e.chat_animation = true;
        e.chat_indicator = false;
        e.discord_presence = false;
        assert!(!e.splitscreen);
        Item::Splitscreen.cycle(&mut e, false);
        assert_eq!(Item::Splitscreen.switch(&e), Some(true));
        Item::WheelCyclesSettings.cycle(&mut e, false);
        assert_eq!(Item::WheelCyclesSettings.switch(&e), Some(false));
        e.fast_background = true;
        e.menu_background_optimization = true;
        e.disable_game_animations = true;
        e.fast_chunk_upload = true;
        e.battery_performance = true;
        e.android_performance_hints = false;
        assert_eq!(e.optimization_level(), 5);
        Optimization::MaxFps.toggle(&mut e);
        assert!(e.max_fps_mode && !e.battery_performance);
        assert_eq!(e.optimization_level(), 5);
        assert_eq!(Extras::parse(&e.serialize()), e);
        e.music_off = vec![
            "minecraft:music/game/calm1".into(),
            "minecraft:music.menu".into(),
        ];
        assert!(!e.music_page);
        Item::MusicPage.cycle(&mut e, false);
        assert_eq!(Item::MusicPage.switch(&e), Some(true));
        assert_eq!(Extras::parse(&e.serialize()), e);
    }

    #[test]
    fn bad_lines_keep_defaults() {
        let e = Extras::parse("zoom:maybe\nzoomLevel:99\nfpsCorner:middle\nzoomKey:z\nnoise");
        assert!(!e.zoom);
        assert_eq!(e.zoom_level, 10);
        assert_eq!(e.fps_corner, Corner::TopLeft);
        assert_eq!(e.zoom_key, "key.keyboard.z");
    }

    #[test]
    fn a_mods_zoom_eases_like_the_spyglass() {
        // Camera.tickFov halves the distance to the target each tick.
        let mut camera = crate::camera::Camera::default();
        camera.tick(None, 1.0);
        for _ in 0..30 {
            camera.tick(None, 1.0);
        }
        let target = fov_target(1.0, 4.0);
        camera.tick(None, target);
        let first = camera.calculate_fov(1.0, 70, 1.0, None, Default::default(), false);
        assert!((first - 70.0 * 0.625).abs() < 1e-3, "{first}");
        for _ in 0..30 {
            camera.tick(None, target);
        }
        let settled = camera.calculate_fov(1.0, 70, 1.0, None, Default::default(), false);
        assert!((settled - 70.0 / 4.0).abs() < 1e-3, "{settled}");
        // Deeper than the 0.1 floor stops there, as vanilla clamps.
        for _ in 0..30 {
            camera.tick(None, fov_target(1.0, 20.0));
        }
        let floor = camera.calculate_fov(1.0, 70, 1.0, None, Default::default(), false);
        assert!((floor - 7.0).abs() < 1e-3, "{floor}");
    }

    #[test]
    fn fps_counter_reports_rate_minimum_and_low() {
        let mut c = FpsCounter::default();
        let mut t = 0.0;
        // Two seconds at 100 fps with one 50 ms hitch.
        for i in 0..200 {
            let ms = if i == 150 { 50.0 } else { 10.0 };
            t += f64::from(ms) / 1000.0;
            c.record(t, ms);
        }
        c.computed_at = f64::NEG_INFINITY;
        c.record(t + 0.01, 10.0);
        let r = c.reading();
        assert!((95..=101).contains(&r.fps), "{r:?}");
        assert_eq!(r.min, 20);
        assert_eq!(r.low, 100, "one frame in 200 is under the 1% mark");
        // Hitches beyond 1% of frames pull the 1% low down.
        let mut c = FpsCounter::default();
        let mut t = 0.0;
        for i in 0..100 {
            let ms = if i % 25 == 0 { 40.0 } else { 10.0 };
            t += f64::from(ms) / 1000.0;
            c.record(t, ms);
        }
        c.computed_at = f64::NEG_INFINITY;
        c.record(t, 10.0);
        assert_eq!(c.reading().low, 25);
    }

    #[test]
    fn old_frames_leave_the_window() {
        let mut c = FpsCounter::default();
        c.record(0.0, 100.0);
        for i in 1..=700 {
            c.record(f64::from(i) / 100.0, 10.0);
        }
        assert_eq!(c.reading().min, 100, "the 100 ms frame is 7 s old");
    }

    #[test]
    fn cps_counts_the_last_second() {
        let mut cps = Cps::default();
        for i in 0..10 {
            cps.click(f64::from(i) * 0.1);
        }
        assert_eq!(cps.per_second(0.95), 10);
        assert_eq!(cps.per_second(1.25), 7);
        assert_eq!(cps.per_second(3.0), 0);
    }

    #[test]
    fn items_cycle_through_their_values() {
        let mut e = Extras::default();
        Item::Sort.cycle(&mut e, true);
        assert_eq!(Item::Sort.value(&e), "On");
        assert_eq!(Extras::parse("minimap:true\nminimapSize:7\nminimapZoom:3"), Extras::default());
        for item in rows().into_iter().flatten() {
            assert!(!item.caption().is_empty() && !item.description().is_empty());
        }
    }
}
